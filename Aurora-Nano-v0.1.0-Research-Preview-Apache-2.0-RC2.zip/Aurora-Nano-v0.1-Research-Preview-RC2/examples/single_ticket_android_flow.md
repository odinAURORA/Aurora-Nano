# Example: Generate One Prompt

```bash
python android_test_kit/tools/make_prompt.py \
  android_test_kit/tickets_25/b1-l001_ticket.json \
  > outputs/prompt_001.txt
```

Feed `prompt_001.txt` to a local model, save the result, then repair and score it.

```bash
python android_test_kit/tools/json_repair_wrapper.py \
  --raw outputs/raw_001.txt \
  --ticket android_test_kit/tickets_25/b1-l001_ticket.json \
  --out outputs/oracle_001.json

python android_test_kit/tools/score_one.py \
  android_test_kit/tickets_25/b1-l001_ticket.json \
  outputs/oracle_001.json
```
