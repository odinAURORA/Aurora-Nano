# Aurora Nano

**Aurora Nano v0.1 Research Preview** is a lightweight runtime and evaluation framework for improving consistency, contradiction handling, escalation behavior, and structured decision quality in small language models.

Aurora is designed around a simple thesis:

```text
small model + structured runtime > small model alone
```

The current target range is approximately **3B–7B parameter models**, especially local and edge deployments.

## Current Status

Aurora Nano v0.1 is a **research preview**, not a production system.

Current release includes:

- synthetic benchmark suites
- validation and scoring tools
- Android/Termux-friendly testing kit
- lightweight Aurora runtime v0.1
- JSON validity and repair utilities
- model-only vs runtime+model comparison tooling
- compute/latency audit templates

What is not yet complete:

- real-world production validation
- domain-specific compliance certification
- real customer data evaluation
- independent external benchmarking

## Why Aurora?

Small models are fast, cheap, private, and deployable on edge devices. But they often struggle with:

- contradictory claims
- source conflicts
- policy exceptions
- escalation decisions
- structured audit trails
- reliable JSON output

Aurora adds a deterministic runtime layer around model extraction.

```text
Ticket
  ↓
Claim extraction
  ↓
Aurora runtime
  ↓
Routing
  ↓
Contradiction / policy / risk checks
  ↓
Decision + confidence + audit log
```

## Quick Start

Run a 25-ticket smoke validation using a model-generated oracle JSON:

```bash
python evaluation/validity/json_validity_analyzer.py \
  --oracle outputs/model_25_oracle.json \
  --suite benchmark_suite/25_ticket_smoke/cases_25.json \
  --suite_dir benchmark_suite/25_ticket_smoke \
  --out outputs/model_25_validity.json \
  --summary outputs/model_25_validity.md
```

Then score the runtime:

```bash
python evaluation/scoring/score_25_smoke.py \
  --oracle outputs/model_25_oracle.json \
  --suite benchmark_suite/25_ticket_smoke/cases_25.json \
  --suite_dir benchmark_suite/25_ticket_smoke \
  --runtime runtime/aurora_runtime_v0_1.py \
  --adapter_scaffold evaluation/scoring/aurora_model_adapter.py \
  --validity_analyzer evaluation/validity/json_validity_analyzer.py \
  --out_dir outputs/c3_25_results \
  --label model_25
```

For Android or Termux testing, see:

```text
android_test_kit/README_ANDROID.md
```

## Repository Map

```text
runtime/                 Aurora runtime v0.1
benchmark_suite/         25-ticket and 250-ticket synthetic benchmarks
evaluation/              validators, scoring, comparison tools
android_test_kit/        phone-friendly testing package
docs/                    architecture, roadmap, IP map, methodology
examples/                example commands and outputs
reports/                 dry-run and forecast reports
```


## Safety and Use Disclaimer

Aurora Nano v0.1 is not production-ready. Do not use it as sole authority for high-impact or safety-critical decisions. See `DISCLAIMER.md`.

## Contributing

Contributions are welcome under Apache 2.0. See `CONTRIBUTING.md`.

## License

Apache License 2.0.

See `LICENSE` and `NOTICE`.

## Important Boundary

The benchmark scores included in this repository are synthetic or dry-run unless explicitly marked as real model results. Do not represent dry-run scores as real-world performance.

## Citation / Attribution

If you use Aurora Nano in research, evaluation, or derivative work, please cite or link back to this repository.
