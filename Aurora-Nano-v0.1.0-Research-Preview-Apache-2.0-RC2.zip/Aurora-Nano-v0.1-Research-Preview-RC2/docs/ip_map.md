# Aurora IP Map v1

This document is a project planning artifact, not legal advice.

## Public / Apache 2.0

Recommended for public release:

- benchmark suite
- evaluation tools
- Android test kit
- documentation
- runtime v0.1 research preview

## Open Core / Reserved

Recommended to keep private until further validation:

- runtime v0.2+
- future governance layers
- advanced contradiction engines
- optimization layers
- model amplification discoveries

## Patent Review Candidates

Potentially worth reviewing before future disclosure:

- runtime-augmented small model architecture
- contradiction-aware decision runtime
- governance-augmented AI decision layer
- small-model amplification methods

## Release Principle

```text
Open what helps adoption.
Protect what creates differentiation.
```

## Boundary

Apache 2.0 does not file patents for the project. If patent protection is important, consult a qualified patent attorney before broad disclosure of potentially novel claims.
