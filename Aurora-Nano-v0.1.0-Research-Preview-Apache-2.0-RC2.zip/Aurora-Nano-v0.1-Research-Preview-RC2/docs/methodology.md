# Benchmark Methodology

Aurora Nano v0.1 evaluates two primary paths:

```text
model-only
runtime + model extraction
```

## Benchmark Suites

### 25-ticket smoke suite

Used for first-pass validation.

### 250-ticket synthetic suite

Used for category-level scoring across:

- lexical contradiction
- temporal/deadline conflict
- source conflict
- policy handling
- resource/escalation behavior

## Metrics

- JSON validity
- schema errors
- runtime score
- model-only score
- runtime-minus-model delta
- category score
- failure clusters
- latency
- throughput

## Important Boundary

Synthetic benchmarks are not substitutes for real-world validation.
