# Aurora Nano v0.1.0 — Research Preview

First public research preview release.

## Includes

- Aurora runtime v0.1
- 25-ticket smoke benchmark
- 250-ticket synthetic benchmark
- evaluation and validation tools
- Android/Termux test kit
- JSON repair utilities
- model-only comparison tooling
- compute/latency audit scripts
- Apache 2.0 license

## Important

This is not a production system. Results are synthetic or dry-run unless explicitly identified as real model results.
