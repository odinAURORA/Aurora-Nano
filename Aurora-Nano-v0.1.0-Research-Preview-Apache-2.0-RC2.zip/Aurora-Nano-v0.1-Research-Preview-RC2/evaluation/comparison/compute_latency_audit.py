#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — C9 Compute / Latency Audit

Purpose:
Audit real-model extraction logs and validation reports.

Inputs:
- B8 batch extraction log JSON
- C2/C3/C4 validity/runtime reports where available

Outputs:
- latency summary
- throughput estimate
- failure counts
- per-ticket runtime distribution
- markdown audit report
"""

from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path
from typing import Any, Dict, List


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def percentile(values: List[float], p: float):
    if not values:
        return None
    values = sorted(values)
    if len(values) == 1:
        return values[0]
    k = (len(values) - 1) * p
    f = int(k)
    c = min(f + 1, len(values) - 1)
    if f == c:
        return values[int(k)]
    return values[f] * (c - k) + values[c] * (k - f)


def summarize_latencies(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    vals = [r.get("runtime_ms") for r in rows if isinstance(r.get("runtime_ms"), (int, float))]
    if not vals:
        return {
            "count": 0,
            "min_ms": None,
            "mean_ms": None,
            "median_ms": None,
            "p95_ms": None,
            "max_ms": None,
            "throughput_tickets_per_minute": None,
        }

    mean = statistics.mean(vals)
    return {
        "count": len(vals),
        "min_ms": min(vals),
        "mean_ms": round(mean, 3),
        "median_ms": round(statistics.median(vals), 3),
        "p95_ms": round(percentile(vals, 0.95), 3),
        "max_ms": max(vals),
        "throughput_tickets_per_minute": round(60000 / mean, 3) if mean else None,
    }


def audit(batch_log: Dict[str, Any], validity: Dict[str, Any] | None, runtime_report: Dict[str, Any] | None) -> Dict[str, Any]:
    rows = batch_log.get("rows", [])
    ok = sum(1 for r in rows if r.get("ok"))
    failed = sum(1 for r in rows if not r.get("ok"))

    errors = {}
    for r in rows:
        if not r.get("ok"):
            err = r.get("error") or "unknown"
            errors[err] = errors.get(err, 0) + 1

    result = {
        "batch": {
            "total": batch_log.get("total_requested", len(rows)),
            "ok": batch_log.get("total_ok", ok),
            "failed": batch_log.get("total_failed", failed),
            "failure_rate": round(failed / len(rows), 4) if rows else None,
        },
        "latency": summarize_latencies(rows),
        "batch_errors": errors,
        "validity": None,
        "runtime_score": None,
    }

    if validity:
        result["validity"] = {
            "ticket_validity_rate": validity.get("ticket_validity_rate"),
            "schema_error_count": validity.get("schema_error_count"),
            "warning_count": validity.get("warning_count"),
            "missing_outputs": validity.get("missing_outputs"),
        }

    if runtime_report:
        # Accept either C4 final report or runtime score report.
        if "runtime_score" in runtime_report:
            score = runtime_report["runtime_score"]
            result["runtime_score"] = {
                "total": score.get("total"),
                "passed": score.get("passed"),
                "failed": score.get("failed"),
                "score": score.get("score"),
                "category_scores": score.get("category_scores"),
            }
        elif "score" in runtime_report:
            score = runtime_report["score"]
            result["runtime_score"] = {
                "total": score.get("total"),
                "passed": score.get("passed"),
                "failed": score.get("failed"),
                "score": score.get("score"),
                "category_scores": score.get("category_scores"),
            }

    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_log", required=True)
    parser.add_argument("--validity_report", required=False)
    parser.add_argument("--runtime_report", required=False)
    parser.add_argument("--out_json", required=True)
    parser.add_argument("--out_md", required=True)
    parser.add_argument("--label", default="compute_latency_audit")
    args = parser.parse_args()

    batch_log = load_json(Path(args.batch_log))
    validity = load_json(Path(args.validity_report)) if args.validity_report else None
    runtime_report = load_json(Path(args.runtime_report)) if args.runtime_report else None

    result = audit(batch_log, validity, runtime_report)
    result["label"] = args.label
    result["inputs"] = {
        "batch_log": args.batch_log,
        "validity_report": args.validity_report,
        "runtime_report": args.runtime_report,
    }

    Path(args.out_json).write_text(json.dumps(result, indent=2), encoding="utf-8")

    validity_lines = "Not provided."
    if result["validity"]:
        validity_lines = f"""- Ticket validity rate: {result['validity']['ticket_validity_rate']}
- Schema errors: {result['validity']['schema_error_count']}
- Warnings: {result['validity']['warning_count']}
- Missing outputs: {result['validity']['missing_outputs']}"""

    score_lines = "Not provided."
    if result["runtime_score"]:
        score_lines = f"""- Total: {result['runtime_score']['total']}
- Passed: {result['runtime_score']['passed']}
- Failed: {result['runtime_score']['failed']}
- Score: {result['runtime_score']['score']}"""

    md = f"""# Aurora C9 Compute / Latency Audit

## Label
{args.label}

## Batch Extraction
- Total: {result['batch']['total']}
- OK: {result['batch']['ok']}
- Failed: {result['batch']['failed']}
- Failure rate: {result['batch']['failure_rate']}

## Latency
- Count: {result['latency']['count']}
- Min ms: {result['latency']['min_ms']}
- Mean ms: {result['latency']['mean_ms']}
- Median ms: {result['latency']['median_ms']}
- P95 ms: {result['latency']['p95_ms']}
- Max ms: {result['latency']['max_ms']}
- Throughput tickets/minute: {result['latency']['throughput_tickets_per_minute']}

## Validity
{validity_lines}

## Runtime Score
{score_lines}

## Batch Errors
```json
{json.dumps(result['batch_errors'], indent=2)}
```

## Notes
For real local/API model tests, report hardware and serving stack manually:
- CPU
- GPU / VRAM
- RAM
- model quantization
- inference server
- context length
- temperature
"""
    Path(args.out_md).write_text(md, encoding="utf-8")

    print(json.dumps({
        "batch_total": result["batch"]["total"],
        "batch_failed": result["batch"]["failed"],
        "mean_ms": result["latency"]["mean_ms"],
        "p95_ms": result["latency"]["p95_ms"],
        "out_json": args.out_json,
        "out_md": args.out_md,
    }, indent=2))


if __name__ == "__main__":
    main()
