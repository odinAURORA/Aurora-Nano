#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — C6 Combined Comparison Report Generator

Compares:
- model-only baseline report from C5
- runtime+model report from C4

Produces:
- JSON combined report
- Markdown executive summary
- category delta table
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def get_model_only_score(report):
    return report["score"]


def get_runtime_model_score(report):
    return report["runtime_score"]


def normalize_category_scores(score_obj):
    return score_obj.get("category_scores", {}) or {}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_only_report", required=True)
    parser.add_argument("--runtime_model_report", required=True)
    parser.add_argument("--out_json", required=True)
    parser.add_argument("--out_md", required=True)
    parser.add_argument("--label", default="comparison")
    args = parser.parse_args()

    model_only = load_json(Path(args.model_only_report))
    runtime_model = load_json(Path(args.runtime_model_report))

    model_score = get_model_only_score(model_only)
    runtime_score = get_runtime_model_score(runtime_model)

    model_cats = normalize_category_scores(model_score)
    runtime_cats = normalize_category_scores(runtime_score)

    all_categories = sorted(set(model_cats) | set(runtime_cats))
    category_deltas = {}

    for cat in all_categories:
        m = model_cats.get(cat, {"score": None, "passed": None, "total": None})
        r = runtime_cats.get(cat, {"score": None, "passed": None, "total": None})
        delta = None
        if m.get("score") is not None and r.get("score") is not None:
            delta = round(r["score"] - m["score"], 4)
        category_deltas[cat] = {
            "model_only": m,
            "runtime_model": r,
            "delta_runtime_minus_model": delta,
        }

    overall_delta = round(runtime_score["score"] - model_score["score"], 4)

    combined = {
        "label": args.label,
        "model_only": {
            "total": model_score.get("total"),
            "passed": model_score.get("passed"),
            "failed": model_score.get("failed"),
            "score": model_score.get("score"),
            "validity": model_only.get("validity", {}),
        },
        "runtime_plus_model": {
            "total": runtime_score.get("total"),
            "passed": runtime_score.get("passed"),
            "failed": runtime_score.get("failed"),
            "score": runtime_score.get("score"),
            "validity": runtime_model.get("validity", {}),
        },
        "overall_delta_runtime_minus_model": overall_delta,
        "category_deltas": category_deltas,
        "verdict": {
            "runtime_beats_model_only": overall_delta > 0,
            "runtime_matches_model_only": overall_delta == 0,
            "runtime_underperforms_model_only": overall_delta < 0,
            "delta_at_least_10_points": overall_delta >= 0.10,
        },
        "inputs": {
            "model_only_report": args.model_only_report,
            "runtime_model_report": args.runtime_model_report,
        },
    }

    Path(args.out_json).write_text(json.dumps(combined, indent=2), encoding="utf-8")

    rows = []
    for cat, d in category_deltas.items():
        m = d["model_only"]
        r = d["runtime_model"]
        rows.append(
            f"| {cat} | {m.get('passed')}/{m.get('total')} | {m.get('score')} | "
            f"{r.get('passed')}/{r.get('total')} | {r.get('score')} | {d['delta_runtime_minus_model']} |"
        )

    md = f"""# Aurora C6 Combined Comparison Summary

## Label
{args.label}

## Overall

| System | Passed | Score |
|---|---:|---:|
| Model-only | {model_score.get('passed')}/{model_score.get('total')} | {model_score.get('score')} |
| Runtime + model extraction | {runtime_score.get('passed')}/{runtime_score.get('total')} | {runtime_score.get('score')} |

## Delta

```text
Runtime minus model-only: {overall_delta}
```

## Verdict

```json
{json.dumps(combined['verdict'], indent=2)}
```

## Category Deltas

| Category | Model-only Passed | Model-only Score | Runtime+Model Passed | Runtime+Model Score | Delta |
|---|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

## Boundary
If this report uses dry-run/oracle outputs, it validates pipeline behavior only. Real model claims require real model-generated outputs.
"""
    Path(args.out_md).write_text(md, encoding="utf-8")

    print(json.dumps({
        "overall_delta_runtime_minus_model": overall_delta,
        "verdict": combined["verdict"],
        "out_json": args.out_json,
        "out_md": args.out_md,
    }, indent=2))


if __name__ == "__main__":
    main()
