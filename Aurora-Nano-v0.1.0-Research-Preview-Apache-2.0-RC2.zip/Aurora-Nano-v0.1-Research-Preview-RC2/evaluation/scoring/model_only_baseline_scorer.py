#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — C5 Model-Only Baseline Scoring Pipeline

Purpose:
Score a model that outputs benchmark decisions directly, without Aurora runtime.

Expected model-only output oracle format:
{
  "TICKET-ID": {
    "router_mode": 1,
    "decision": "string",
    "confidence": {
      "overall_confidence": 0.0,
      "escalation_recommended": false
    },
    "findings": [
      {"type": "lexical_contradiction", "severity": "medium"}
    ],
    "notes": []
  }
}

This creates a fair comparison target:
- model-only
vs
- Aurora runtime + model extraction
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_model_output(item: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "router_mode": item.get("router_mode"),
        "decision": item.get("decision", ""),
        "confidence": {
            "overall_confidence": float(item.get("confidence", {}).get("overall_confidence", 0.5)),
            "escalation_recommended": bool(item.get("confidence", {}).get("escalation_recommended", False)),
        },
        "audit_log": {
            "findings": item.get("findings", []),
            "runtime_ms": item.get("runtime_ms"),
        },
    }


def finding_types(result: Dict[str, Any]) -> List[str]:
    return [f.get("type", "") for f in result.get("audit_log", {}).get("findings", [])]


def score_case(case: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    exp = case["expected"]
    types = finding_types(result)
    checks = []

    def add(name, passed, expected, actual):
        checks.append({"check": name, "passed": bool(passed), "expected": expected, "actual": actual})

    if "router_mode" in exp:
        add("router_mode", result.get("router_mode") == exp["router_mode"], exp["router_mode"], result.get("router_mode"))
    if "decision" in exp:
        add("decision", result.get("decision") == exp["decision"], exp["decision"], result.get("decision"))
    if "decision_contains" in exp:
        add("decision_contains", exp["decision_contains"] in result.get("decision", ""), exp["decision_contains"], result.get("decision"))
    if "escalation" in exp:
        actual = result.get("confidence", {}).get("escalation_recommended")
        add("escalation", actual == exp["escalation"], exp["escalation"], actual)
    for req in exp.get("required_findings", []):
        add(f"required_finding:{req}", req in types, req, types)
    for forb in exp.get("forbidden_findings", []):
        add(f"forbidden_finding:{forb}", forb not in types, f"not {forb}", types)

    return {
        "case_id": case["case_id"],
        "category": case.get("category", "unknown"),
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "actual": {
            "router_mode": result.get("router_mode"),
            "decision": result.get("decision"),
            "confidence": result.get("confidence", {}).get("overall_confidence"),
            "escalation": result.get("confidence", {}).get("escalation_recommended"),
            "finding_types": types,
        },
    }


def validate_model_only_oracle(oracle: Dict[str, Any], expected_ticket_ids: List[str]) -> Dict[str, Any]:
    errors = []
    warnings = []
    expected = set(expected_ticket_ids)
    present = set(oracle.keys())

    for tid in sorted(expected - present):
        errors.append({"ticket_id": tid, "type": "missing_model_output"})

    for tid in sorted(present - expected):
        warnings.append({"ticket_id": tid, "type": "extra_model_output"})

    valid = 0
    for tid in sorted(expected & present):
        item = oracle[tid]
        before = len(errors)

        if not isinstance(item, dict):
            errors.append({"ticket_id": tid, "type": "output_not_object"})
            continue

        if "router_mode" not in item:
            errors.append({"ticket_id": tid, "type": "missing_router_mode"})
        else:
            try:
                mode = int(item["router_mode"])
                if mode < 0 or mode > 4:
                    errors.append({"ticket_id": tid, "type": "router_mode_out_of_range", "actual": item["router_mode"]})
            except Exception:
                errors.append({"ticket_id": tid, "type": "router_mode_not_int", "actual": item.get("router_mode")})

        if "decision" not in item or not isinstance(item.get("decision"), str):
            errors.append({"ticket_id": tid, "type": "missing_or_invalid_decision"})

        conf = item.get("confidence")
        if not isinstance(conf, dict):
            errors.append({"ticket_id": tid, "type": "confidence_not_object"})
        else:
            try:
                val = float(conf.get("overall_confidence"))
                if val < 0 or val > 1:
                    errors.append({"ticket_id": tid, "type": "confidence_out_of_range", "actual": val})
            except Exception:
                errors.append({"ticket_id": tid, "type": "confidence_not_numeric", "actual": conf.get("overall_confidence")})
            if not isinstance(conf.get("escalation_recommended"), bool):
                errors.append({"ticket_id": tid, "type": "escalation_not_bool", "actual": conf.get("escalation_recommended")})

        findings = item.get("findings", [])
        if not isinstance(findings, list):
            errors.append({"ticket_id": tid, "type": "findings_not_list"})

        if len(errors) == before:
            valid += 1

    total = len(expected_ticket_ids)
    return {
        "total_expected": total,
        "present_expected": len(expected & present),
        "missing_outputs": len(expected - present),
        "valid_outputs": valid,
        "invalid_outputs": total - valid,
        "validity_rate": round(valid / total, 4) if total else 0,
        "error_count": len(errors),
        "warning_count": len(warnings),
        "errors": errors,
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_outputs", required=True)
    parser.add_argument("--suite", required=True)
    parser.add_argument("--suite_dir", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--label", default="model_only")
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    oracle = load_json(Path(args.model_outputs))
    cases = load_json(Path(args.suite))
    suite_dir = Path(args.suite_dir)

    expected_ticket_ids = []
    for case in cases:
        ticket = load_json(suite_dir / case["ticket_file"])
        expected_ticket_ids.append(ticket["ticket_id"])

    validity = validate_model_only_oracle(oracle, expected_ticket_ids)

    results, errors = [], []
    for case in cases:
        try:
            ticket = load_json(suite_dir / case["ticket_file"])
            tid = ticket["ticket_id"]
            if tid not in oracle:
                errors.append({"case_id": case["case_id"], "error": "missing_output"})
                continue
            normalized = normalize_model_output(oracle[tid])
            results.append(score_case(case, normalized))
        except Exception as e:
            errors.append({"case_id": case.get("case_id"), "error": repr(e)})

    passed = sum(1 for r in results if r["passed"])
    by_cat = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0})
    for r in results:
        by_cat[r["category"]]["total"] += 1
        by_cat[r["category"]]["passed"] += int(r["passed"])
        by_cat[r["category"]]["failed"] += int(not r["passed"])

    category_scores = {
        cat: {**d, "score": round(d["passed"] / d["total"], 4) if d["total"] else 0}
        for cat, d in by_cat.items()
    }

    report = {
        "label": args.label,
        "model_outputs": args.model_outputs,
        "validity": validity,
        "score": {
            "total": len(cases),
            "scored": len(results),
            "passed": passed,
            "failed": len(cases) - passed,
            "score": round(passed / len(cases), 4) if cases else 0,
            "category_scores": category_scores,
        },
        "results": results,
        "errors": errors,
    }

    report_path = out_dir / f"{args.label}_model_only_report.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    cat_lines = []
    for cat, d in sorted(category_scores.items()):
        cat_lines.append(f"| {cat} | {d['passed']}/{d['total']} | {d['score']} |")

    summary_path = out_dir / f"{args.label}_model_only_summary.md"
    summary_path.write_text(f"""# Aurora C5 Model-Only Baseline Summary

## Label
{args.label}

## Validity
- Expected: {validity['total_expected']}
- Present: {validity['present_expected']}
- Valid outputs: {validity['valid_outputs']}
- Validity rate: {validity['validity_rate']}
- Errors: {validity['error_count']}
- Warnings: {validity['warning_count']}

## Score
- Total: {report['score']['total']}
- Passed: {report['score']['passed']}
- Failed: {report['score']['failed']}
- Score: {report['score']['score']}

## Category Scores

| Category | Passed | Score |
|---|---:|---:|
{chr(10).join(cat_lines)}
""", encoding="utf-8")

    print(json.dumps({
        "validity_rate": validity["validity_rate"],
        "error_count": validity["error_count"],
        "score": report["score"]["score"],
        "report": str(report_path),
        "summary": str(summary_path),
    }, indent=2))


if __name__ == "__main__":
    main()
