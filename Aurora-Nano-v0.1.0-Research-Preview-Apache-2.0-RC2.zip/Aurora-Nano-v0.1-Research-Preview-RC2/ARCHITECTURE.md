# Aurora Nano Architecture

## Design Goal

Aurora Nano is designed to improve small-model decision reliability without requiring a larger model.

The core design pattern is:

```text
Language model = extraction and flexible interpretation
Aurora runtime = deterministic structure, contradiction checks, routing, confidence, audit
```

## Runtime Flow

```text
Input ticket
  ↓
Claim extraction
  ↓
Router mode selection
  ↓
Runtime modules
  ↓
Confidence engine
  ↓
Decision
  ↓
Audit log
```

## Router Modes

```text
Mode 0: Direct response
Mode 1: Extraction + contradiction check
Mode 2: Policy + confidence
Mode 3: Full decision kernel
Mode 4: Reflective review
```

## Core Modules

Aurora Nano v0.1 includes deterministic modules for:

- lexical contradiction detection
- temporal/deadline conflict detection
- source/perspective conflict detection
- policy requirement detection
- capacity/resource awareness
- self-critique hooks
- counterexample hooks
- failure prediction hooks
- confidence calibration

## Output Object

Aurora produces:

```json
{
  "router_mode": 2,
  "decision": "apply_policy_context",
  "confidence": {},
  "module_results": [],
  "audit_log": {}
}
```

## Boundary

Aurora runtime quality depends heavily on extraction quality. If the model extracts poor claims, the runtime cannot reliably recover missing information.
