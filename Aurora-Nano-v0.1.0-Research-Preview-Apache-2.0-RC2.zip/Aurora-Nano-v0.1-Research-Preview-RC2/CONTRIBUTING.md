# Contributing

Thanks for considering a contribution to Aurora Nano.

## Contribution Terms

Unless explicitly stated otherwise, any contribution submitted to this repository is provided under the Apache License 2.0.

## Good First Contributions

- documentation fixes
- benchmark issue reports
- reproduction notes
- local model validation reports
- Android/Termux setup improvements

## Please Do Not Submit

- private data
- real customer support tickets
- regulated personal data
- safety-critical deployment claims without evidence
- code copied from incompatible licenses

## Validation Reports

If contributing benchmark results, include:

- model name and version
- local/API runtime
- hardware
- benchmark suite version
- JSON validity
- runtime score
- model-only score if available
- whether JSON repair was used
