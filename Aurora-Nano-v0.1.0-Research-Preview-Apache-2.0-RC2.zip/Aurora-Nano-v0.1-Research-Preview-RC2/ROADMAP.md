# Aurora Nano Roadmap

## v0.1 Research Preview

Public release goals:

- publish benchmark suite
- publish runtime v0.1
- publish evaluation tools
- publish Android test kit
- enable local model testing
- collect real model results

## Near-Term Validation Targets

Priority order:

1. Qwen3 4B
2. Llama 3.2 3B
3. Gemma 3 4B
4. Phi-4-mini
5. SmolLM3 3B

## Evidence Goals

For each model:

- JSON validity
- schema errors
- runtime+model score
- model-only score
- category deltas
- latency and throughput
- failure clusters

## v0.2 Goals

Potential improvements after real benchmark evidence:

- stronger extraction schema
- better model-only prompt suite
- richer source conflict normalization
- improved confidence calibration
- real-world messy ticket benchmark
- Hugging Face dataset release

## Non-Goals for v0.1

- production decision authority
- safety-critical deployment
- medical/legal/financial advice
- autonomous high-impact decisions
