# Disclaimer

Aurora Nano v0.1 is a research preview. It is not production-ready and must not be used as sole authority for safety-critical, legal, medical, financial, employment, housing, law-enforcement, or other high-impact decisions.

Included benchmark results are synthetic or dry-run unless explicitly labeled as real model results. Users are responsible for independent validation before applying Aurora Nano to any real-world workflow.

This repository is not legal, patent, medical, financial, or compliance advice.
