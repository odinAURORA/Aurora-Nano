# Changelog

## v0.1.0 — Research Preview

Initial public release.

Includes:

- Aurora Nano runtime v0.1
- 25-ticket smoke benchmark
- 250-ticket synthetic benchmark
- JSON validity analyzer
- scoring pipelines
- model-only baseline scorer
- runtime+model comparison generator
- Android/Termux test kit
- JSON repair utilities
- compute/latency audit template
- architecture and roadmap documentation

Known limitations:

- no real model results bundled as official claims
- synthetic benchmark only
- extraction quality remains the key bottleneck
