# Aurora Android Real Model Test Kit

This kit is built for testing Aurora Nano with local models on an Android phone, especially through Termux or another local Python-capable environment.

## What This Kit Does

It lets you test:

```text
local phone model extraction
→ Aurora runtime
→ JSON validity
→ 25-ticket smoke score
→ optional 250-ticket full score
```

## Folder Map

```text
runtime/      Aurora runtime
tools/        validators, scoring scripts, prompt generator, repair tools
tickets_25/   small smoke benchmark
tickets_250/  full synthetic benchmark
scripts/      phone-friendly shell scripts
outputs/      put model outputs here
docs/         notes and commands
```

## First Test: One Ticket Manually

Generate a prompt:

```bash
python tools/make_prompt.py tickets_25/b1-l001_ticket.json > outputs/prompt_001.txt
```

Paste `outputs/prompt_001.txt` into your local phone model.

Save the model JSON output as:

```text
outputs/raw_001.txt
```

Repair/normalize if needed:

```bash
python tools/json_repair_wrapper.py \
  --raw outputs/raw_001.txt \
  --ticket tickets_25/b1-l001_ticket.json \
  --out outputs/oracle_001.json
```

Score one ticket:

```bash
python tools/score_one.py tickets_25/b1-l001_ticket.json outputs/oracle_001.json
```

## 25-Ticket Smoke Test

Create one oracle file:

```text
outputs/model_25_oracle.json
```

Format:

```json
{
  "B1-L001": {
    "claims": [],
    "suggested_router_mode": null,
    "notes": []
  }
}
```

Then run:

```bash
bash scripts/score_25_oracle.sh
```

## Full 250 Test

Create:

```text
outputs/model_250_oracle.json
```

Then run:

```bash
bash scripts/score_250_oracle.sh
```

## Success Gates

25-ticket smoke:
- JSON validity >= 95%
- schema errors = 0
- runtime score >= 80%

Full 250:
- JSON validity >= 95%
- runtime score >= 80%
- strong target: >=90%

## Important Boundary

This kit does not include the model itself. It evaluates outputs from your phone model.
