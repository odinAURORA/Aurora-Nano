#!/usr/bin/env python3
"""
Score one repaired/extracted oracle JSON against Aurora.
Useful for phone testing one ticket at a time.
"""
import json, sys, importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
runtime_path = ROOT / "runtime" / "aurora_runtime.py"

spec = importlib.util.spec_from_file_location("aurora_runtime", runtime_path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

if len(sys.argv) != 3:
    raise SystemExit("Usage: python score_one.py ticket.json oracle.json")

ticket_data = json.loads(Path(sys.argv[1]).read_text())
oracle = json.loads(Path(sys.argv[2]).read_text())
tid = ticket_data["ticket_id"]
item = oracle.get(tid) or next(iter(oracle.values()))

claims = item.get("claims", [])
forced = item.get("suggested_router_mode")

runtime = mod.AuroraNanoRuntime()
ticket = mod.Ticket(**ticket_data)
result = runtime.run(ticket, external_claims=claims, forced_router_mode=forced)
print(json.dumps({
    "ticket_id": tid,
    "router_mode": result["router_mode"],
    "decision": result["decision"],
    "confidence": result["confidence"],
    "findings": result["audit_log"]["findings"],
}, indent=2))
