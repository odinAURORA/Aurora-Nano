#!/usr/bin/env python3
import json, sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("Usage: python make_prompt.py ticket.json")

ticket = json.loads(Path(sys.argv[1]).read_text())

schema = {
  "claims": [
    {
      "source": "customer|agent|system|policy|external",
      "claim_type": "fact|belief|report|inference|policy|observation",
      "subject": "string",
      "predicate": "string",
      "object": "string",
      "confidence": 0.0,
      "evidence": []
    }
  ],
  "suggested_router_mode": None,
  "notes": []
}

print("You are the extraction layer for Aurora Nano.")
print("Return ONLY valid JSON. No markdown. No prose.")
print("Schema:")
print(json.dumps(schema, indent=2))
print("Ticket:")
print(json.dumps(ticket, indent=2))
