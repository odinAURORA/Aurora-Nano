#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — C3 25-Ticket Smoke Scoring Pipeline

Given a model-generated oracle JSON:
1. Validate JSON/schema with C2 analyzer.
2. Score Aurora runtime + external extraction against a 25-ticket subset.
3. Write final JSON and markdown reports.

This script is subprocess-light and avoids printing huge comparator payloads.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from collections import defaultdict
from pathlib import Path


def import_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def finding_types(result):
    return [f.get("type", "") for f in result.get("audit_log", {}).get("findings", [])]


def score_case(case, result):
    exp = case["expected"]
    types = finding_types(result)
    checks = []

    def add(name, passed, expected, actual):
        checks.append({"check": name, "passed": bool(passed), "expected": expected, "actual": actual})

    if "router_mode" in exp:
        add("router_mode", result.get("router_mode") == exp["router_mode"], exp["router_mode"], result.get("router_mode"))
    if "decision" in exp:
        add("decision", result.get("decision") == exp["decision"], exp["decision"], result.get("decision"))
    if "decision_contains" in exp:
        add("decision_contains", exp["decision_contains"] in result.get("decision", ""), exp["decision_contains"], result.get("decision"))
    if "escalation" in exp:
        actual = result.get("confidence", {}).get("escalation_recommended")
        add("escalation", actual == exp["escalation"], exp["escalation"], actual)
    for req in exp.get("required_findings", []):
        add(f"required_finding:{req}", req in types, req, types)
    for forb in exp.get("forbidden_findings", []):
        add(f"forbidden_finding:{forb}", forb not in types, f"not {forb}", types)

    return {
        "case_id": case["case_id"],
        "category": case.get("category", "unknown"),
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "actual": {
            "router_mode": result.get("router_mode"),
            "decision": result.get("decision"),
            "confidence": result.get("confidence", {}).get("overall_confidence"),
            "escalation": result.get("confidence", {}).get("escalation_recommended"),
            "finding_types": types,
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle", required=True)
    parser.add_argument("--suite", required=True)
    parser.add_argument("--suite_dir", required=True)
    parser.add_argument("--runtime", required=True)
    parser.add_argument("--adapter_scaffold", required=True)
    parser.add_argument("--validity_analyzer", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--label", default="model_smoke")
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    analyzer = import_module(Path(args.validity_analyzer), "c2_analyzer")
    runtime_mod = import_module(Path(args.runtime), "aurora_runtime_c3")
    adapter_mod = import_module(Path(args.adapter_scaffold), "aurora_adapters_c3")

    oracle_path = Path(args.oracle)
    suite_path = Path(args.suite)
    suite_dir = Path(args.suite_dir)
    cases = load_json(suite_path)
    oracle = load_json(oracle_path)

    expected_ticket_ids = []
    for case in cases:
        ticket = load_json(suite_dir / case["ticket_file"])
        expected_ticket_ids.append(ticket["ticket_id"])

    validity = analyzer.analyze_oracle(oracle, expected_ticket_ids)

    validity_report = out_dir / f"{args.label}_validity_report.json"
    validity_report.write_text(json.dumps(validity, indent=2), encoding="utf-8")

    extractor = adapter_mod.OracleJsonExtractor(oracle_path)
    runtime = runtime_mod.AuroraNanoRuntime()

    results, errors = [], []
    for case in cases:
        try:
            ticket_data = load_json(suite_dir / case["ticket_file"])
            extracted = extractor.extract(ticket_data)
            external_claims = [
                {
                    "source": c.source,
                    "claim_type": c.claim_type,
                    "subject": c.subject,
                    "predicate": c.predicate,
                    "object": c.object,
                    "confidence": c.confidence,
                    "evidence": c.evidence,
                }
                for c in extracted.claims
            ]
            ticket = runtime_mod.Ticket(**ticket_data)
            result = runtime.run(
                ticket,
                external_claims=external_claims,
                forced_router_mode=extracted.suggested_router_mode,
            )
            results.append(score_case(case, result))
        except Exception as e:
            errors.append({"case_id": case.get("case_id"), "error": repr(e)})

    passed = sum(1 for r in results if r["passed"])
    by_cat = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0})
    for r in results:
        by_cat[r["category"]]["total"] += 1
        by_cat[r["category"]]["passed"] += int(r["passed"])
        by_cat[r["category"]]["failed"] += int(not r["passed"])

    category_scores = {
        cat: {**d, "score": round(d["passed"] / d["total"], 4) if d["total"] else 0}
        for cat, d in by_cat.items()
    }

    runtime_score = {
        "total": len(cases),
        "passed": passed,
        "failed": len(cases) - passed,
        "score": round(passed / len(cases), 4) if cases else 0,
        "category_scores": category_scores,
        "errors": errors,
        "results": results,
    }

    runtime_report = out_dir / f"{args.label}_runtime_score_report.json"
    runtime_report.write_text(json.dumps(runtime_score, indent=2), encoding="utf-8")

    final = {
        "label": args.label,
        "oracle": str(oracle_path),
        "validity": {
            "total_expected": validity.get("total_expected"),
            "total_present_expected": validity.get("total_present_expected"),
            "missing_outputs": validity.get("missing_outputs"),
            "ticket_validity_rate": validity.get("ticket_validity_rate"),
            "schema_error_count": validity.get("schema_error_count"),
            "warning_count": validity.get("warning_count"),
        },
        "runtime_score": {
            "total": runtime_score["total"],
            "passed": runtime_score["passed"],
            "failed": runtime_score["failed"],
            "score": runtime_score["score"],
            "category_scores": category_scores,
        },
        "pass_gate": {
            "json_validity_min_95": validity.get("ticket_validity_rate", 0) >= 0.95,
            "schema_errors_zero": validity.get("schema_error_count", 999) == 0,
            "runtime_score_min_80_smoke": runtime_score["score"] >= 0.80,
        },
        "files": {
            "validity_report": str(validity_report),
            "runtime_report": str(runtime_report),
        },
    }
    final["overall_smoke_pass"] = all(final["pass_gate"].values())

    final_report = out_dir / f"{args.label}_c3_final_report.json"
    final_report.write_text(json.dumps(final, indent=2), encoding="utf-8")

    cat_lines = []
    for cat, d in sorted(category_scores.items()):
        cat_lines.append(f"| {cat} | {d['passed']}/{d['total']} | {d['score']} |")

    final_summary = out_dir / f"{args.label}_c3_summary.md"
    final_summary.write_text(f"""# Aurora C3 25-Ticket Smoke Pipeline Summary

## Label
{args.label}

## JSON Validity
- Expected tickets: {validity.get('total_expected')}
- Present expected outputs: {validity.get('total_present_expected')}
- Missing outputs: {validity.get('missing_outputs')}
- Ticket validity rate: {validity.get('ticket_validity_rate')}
- Schema errors: {validity.get('schema_error_count')}
- Warnings: {validity.get('warning_count')}

## Runtime Score
- Total: {runtime_score['total']}
- Passed: {runtime_score['passed']}
- Failed: {runtime_score['failed']}
- Score: {runtime_score['score']}

## Category Scores

| Category | Passed | Score |
|---|---:|---:|
{chr(10).join(cat_lines)}

## Pass Gates
```json
{json.dumps(final['pass_gate'], indent=2)}
```

## Overall Smoke Pass
```text
{final['overall_smoke_pass']}
```
""", encoding="utf-8")

    print(json.dumps({
        "overall_smoke_pass": final["overall_smoke_pass"],
        "ticket_validity_rate": final["validity"]["ticket_validity_rate"],
        "schema_error_count": final["validity"]["schema_error_count"],
        "runtime_score": final["runtime_score"]["score"],
        "final_report": str(final_report),
        "final_summary": str(final_summary),
    }, indent=2))


if __name__ == "__main__":
    main()
