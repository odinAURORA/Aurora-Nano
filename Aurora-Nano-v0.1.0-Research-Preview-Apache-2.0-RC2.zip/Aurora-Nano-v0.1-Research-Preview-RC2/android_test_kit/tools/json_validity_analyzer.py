#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — C2 JSON Validity Analyzer

Purpose:
Analyze model extraction oracle JSON before running Aurora scoring.

Expected oracle format:
{
  "TICKET-ID": {
    "claims": [
      {
        "source": "customer|agent|system|policy|external",
        "claim_type": "fact|belief|report|inference|policy|observation",
        "subject": "string",
        "predicate": "string",
        "object": "string",
        "confidence": 0.0,
        "evidence": []
      }
    ],
    "suggested_router_mode": null,
    "notes": []
  }
}

Outputs:
- validity rates
- schema errors
- confidence range errors
- missing ticket outputs
- empty claim outputs
- summary report
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List


REQUIRED_CLAIM_KEYS = {
    "source", "claim_type", "subject", "predicate", "object", "confidence", "evidence"
}

ALLOWED_SOURCES = {"customer", "agent", "system", "policy", "external"}
ALLOWED_TYPES = {"fact", "belief", "report", "inference", "policy", "observation"}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_claim(claim: Any, ticket_id: str, idx: int) -> List[Dict[str, Any]]:
    errors = []
    if not isinstance(claim, dict):
        return [{
            "ticket_id": ticket_id,
            "claim_index": idx,
            "type": "claim_not_object",
            "message": "Claim is not a JSON object."
        }]

    missing = REQUIRED_CLAIM_KEYS - set(claim.keys())
    if missing:
        errors.append({
            "ticket_id": ticket_id,
            "claim_index": idx,
            "type": "missing_claim_keys",
            "missing": sorted(missing),
        })

    source = claim.get("source")
    if source not in ALLOWED_SOURCES:
        errors.append({
            "ticket_id": ticket_id,
            "claim_index": idx,
            "type": "invalid_source",
            "actual": source,
        })

    ctype = claim.get("claim_type")
    if ctype not in ALLOWED_TYPES:
        errors.append({
            "ticket_id": ticket_id,
            "claim_index": idx,
            "type": "invalid_claim_type",
            "actual": ctype,
        })

    try:
        conf = float(claim.get("confidence"))
        if not (0.0 <= conf <= 1.0):
            errors.append({
                "ticket_id": ticket_id,
                "claim_index": idx,
                "type": "confidence_out_of_range",
                "actual": conf,
            })
    except Exception:
        errors.append({
            "ticket_id": ticket_id,
            "claim_index": idx,
            "type": "confidence_not_numeric",
            "actual": claim.get("confidence"),
        })

    evidence = claim.get("evidence")
    if not isinstance(evidence, list):
        errors.append({
            "ticket_id": ticket_id,
            "claim_index": idx,
            "type": "evidence_not_list",
        })

    for key in ["subject", "predicate", "object"]:
        if key in claim and not isinstance(claim[key], str):
            errors.append({
                "ticket_id": ticket_id,
                "claim_index": idx,
                "type": f"{key}_not_string",
                "actual_type": type(claim[key]).__name__,
            })
        elif key in claim and not claim[key].strip():
            errors.append({
                "ticket_id": ticket_id,
                "claim_index": idx,
                "type": f"{key}_empty",
            })

    return errors


def analyze_oracle(oracle: Dict[str, Any], expected_ticket_ids: List[str]) -> Dict[str, Any]:
    errors = []
    warnings = []

    present_ids = set(oracle.keys())
    expected_ids = set(expected_ticket_ids)
    missing_ids = sorted(expected_ids - present_ids)
    extra_ids = sorted(present_ids - expected_ids)

    for tid in missing_ids:
        errors.append({"ticket_id": tid, "type": "missing_ticket_output"})

    for tid in extra_ids:
        warnings.append({"ticket_id": tid, "type": "extra_ticket_output"})

    claim_counts = {}
    source_counts = Counter()
    type_counts = Counter()
    router_mode_counts = Counter()

    valid_ticket_count = 0

    for ticket_id in sorted(present_ids & expected_ids):
        item = oracle[ticket_id]

        if not isinstance(item, dict):
            errors.append({"ticket_id": ticket_id, "type": "ticket_output_not_object"})
            continue

        claims = item.get("claims")
        if not isinstance(claims, list):
            errors.append({"ticket_id": ticket_id, "type": "claims_not_list"})
            claims = []

        if len(claims) == 0:
            warnings.append({"ticket_id": ticket_id, "type": "empty_claims"})

        claim_counts[ticket_id] = len(claims)

        before = len(errors)
        for idx, claim in enumerate(claims):
            errors.extend(validate_claim(claim, ticket_id, idx))
            if isinstance(claim, dict):
                source_counts[str(claim.get("source"))] += 1
                type_counts[str(claim.get("claim_type"))] += 1

        mode = item.get("suggested_router_mode")
        if mode is not None:
            try:
                mode_int = int(mode)
                if mode_int < 0 or mode_int > 4:
                    errors.append({"ticket_id": ticket_id, "type": "router_mode_out_of_range", "actual": mode})
                router_mode_counts[str(mode_int)] += 1
            except Exception:
                errors.append({"ticket_id": ticket_id, "type": "router_mode_not_int", "actual": mode})
        else:
            router_mode_counts["null"] += 1

        notes = item.get("notes", [])
        if notes is not None and not isinstance(notes, list):
            warnings.append({"ticket_id": ticket_id, "type": "notes_not_list"})

        if len(errors) == before:
            valid_ticket_count += 1

    total_expected = len(expected_ticket_ids)
    total_present_expected = len(present_ids & expected_ids)
    total_errors = len(errors)

    return {
        "total_expected": total_expected,
        "total_present_expected": total_present_expected,
        "missing_outputs": len(missing_ids),
        "extra_outputs": len(extra_ids),
        "valid_ticket_outputs": valid_ticket_count,
        "invalid_ticket_outputs": total_present_expected - valid_ticket_count + len(missing_ids),
        "ticket_validity_rate": round(valid_ticket_count / total_expected, 4) if total_expected else 0.0,
        "schema_error_count": total_errors,
        "warning_count": len(warnings),
        "claim_count": {
            "total": sum(claim_counts.values()),
            "min": min(claim_counts.values()) if claim_counts else 0,
            "max": max(claim_counts.values()) if claim_counts else 0,
            "mean": round(sum(claim_counts.values()) / len(claim_counts), 3) if claim_counts else 0,
        },
        "source_counts": dict(source_counts),
        "claim_type_counts": dict(type_counts),
        "router_mode_counts": dict(router_mode_counts),
        "errors": errors,
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle", required=True)
    parser.add_argument("--suite", required=True, help="Benchmark cases JSON containing ticket_file references")
    parser.add_argument("--suite_dir", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--summary", required=False)
    args = parser.parse_args()

    oracle = load_json(Path(args.oracle))
    cases = load_json(Path(args.suite))
    suite_dir = Path(args.suite_dir)

    expected_ticket_ids = []
    for case in cases:
        ticket = load_json(suite_dir / case["ticket_file"])
        expected_ticket_ids.append(ticket["ticket_id"])

    report = analyze_oracle(oracle, expected_ticket_ids)
    Path(args.out).write_text(json.dumps(report, indent=2), encoding="utf-8")

    if args.summary:
        error_preview = report["errors"][:20]
        summary = f"""# Aurora C2 JSON Validity Report

## Result
- Expected tickets: {report['total_expected']}
- Present expected outputs: {report['total_present_expected']}
- Missing outputs: {report['missing_outputs']}
- Valid ticket outputs: {report['valid_ticket_outputs']}
- Invalid ticket outputs: {report['invalid_ticket_outputs']}
- Ticket validity rate: {report['ticket_validity_rate']}
- Schema errors: {report['schema_error_count']}
- Warnings: {report['warning_count']}

## Claim Counts
```json
{json.dumps(report['claim_count'], indent=2)}
```

## Source Counts
```json
{json.dumps(report['source_counts'], indent=2)}
```

## Claim Type Counts
```json
{json.dumps(report['claim_type_counts'], indent=2)}
```

## Error Preview
```json
{json.dumps(error_preview, indent=2)}
```
"""
        Path(args.summary).write_text(summary, encoding="utf-8")

    print(json.dumps({
        "ticket_validity_rate": report["ticket_validity_rate"],
        "schema_error_count": report["schema_error_count"],
        "missing_outputs": report["missing_outputs"],
        "warning_count": report["warning_count"],
        "out": args.out,
    }, indent=2))


if __name__ == "__main__":
    main()
