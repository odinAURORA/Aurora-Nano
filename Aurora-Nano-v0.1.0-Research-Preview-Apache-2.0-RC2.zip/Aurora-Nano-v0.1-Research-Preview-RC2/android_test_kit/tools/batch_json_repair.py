#!/usr/bin/env python3
"""
Aurora C8 Batch Repair

Repairs a folder of raw model outputs named by ticket_id or case_id.

Expected raw files:
- <ticket_id>.txt or <ticket_id>.json

Outputs a single oracle JSON map.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path


def import_repair(path: Path):
    spec = importlib.util.spec_from_file_location("repair_mod", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["repair_mod"] = mod
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw_dir", required=True)
    parser.add_argument("--suite", required=True)
    parser.add_argument("--suite_dir", required=True)
    parser.add_argument("--repair_script", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--log", required=True)
    args = parser.parse_args()

    repair = import_repair(Path(args.repair_script))
    raw_dir = Path(args.raw_dir)
    suite = load_json(Path(args.suite))
    suite_dir = Path(args.suite_dir)

    oracle = {}
    rows = []

    for case in suite:
        ticket_path = suite_dir / case["ticket_file"]
        ticket = load_json(ticket_path)
        tid = ticket["ticket_id"]

        candidates = [
            raw_dir / f"{tid}.txt",
            raw_dir / f"{tid}.json",
            raw_dir / f"{case['case_id']}.txt",
            raw_dir / f"{case['case_id']}.json",
        ]
        raw_path = next((p for p in candidates if p.exists()), None)

        if not raw_path:
            rows.append({"ticket_id": tid, "case_id": case["case_id"], "ok": False, "error": "missing_raw_output"})
            continue

        try:
            repaired = repair.repair_file(raw_path, ticket_path, None)
            oracle.update(repaired)
            rows.append({"ticket_id": tid, "case_id": case["case_id"], "ok": True, "raw": str(raw_path)})
        except Exception as e:
            rows.append({"ticket_id": tid, "case_id": case["case_id"], "ok": False, "raw": str(raw_path), "error": repr(e)})

    Path(args.out).write_text(json.dumps(oracle, indent=2), encoding="utf-8")
    Path(args.log).write_text(json.dumps({
        "total": len(suite),
        "ok": sum(1 for r in rows if r["ok"]),
        "failed": sum(1 for r in rows if not r["ok"]),
        "rows": rows,
    }, indent=2), encoding="utf-8")

    print(json.dumps({
        "total": len(suite),
        "ok": sum(1 for r in rows if r["ok"]),
        "failed": sum(1 for r in rows if not r["ok"]),
        "out": args.out,
        "log": args.log,
    }, indent=2))


if __name__ == "__main__":
    main()
