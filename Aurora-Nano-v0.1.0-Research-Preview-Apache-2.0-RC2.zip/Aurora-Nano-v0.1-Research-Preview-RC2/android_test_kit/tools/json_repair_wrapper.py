#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — C8 JSON Repair / Normalization Wrapper

Purpose:
Small local models often output:
- markdown fences
- prose around JSON
- trailing commas
- missing notes
- single object instead of oracle map
- confidence as string

This wrapper attempts conservative repair and normalization.

Important:
- It does NOT invent missing substantive claims.
- It only repairs structure enough for C2 validation.
- Any repaired output is tagged in notes.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict


REQUIRED_CLAIM_DEFAULTS = {
    "source": "customer",
    "claim_type": "report",
    "subject": "ticket",
    "predicate": "states",
    "object": "",
    "confidence": 0.5,
    "evidence": [],
}


def strip_code_fences(text: str) -> str:
    text = text.strip()
    # Remove markdown fences if present.
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def extract_first_json_blob(text: str) -> str:
    text = strip_code_fences(text)
    # If already JSON-ish, return.
    if text.startswith("{") and text.endswith("}"):
        return text
    # Find first balanced-ish object by first { and last }.
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return text[start:end+1]
    raise ValueError("No JSON object found.")


def remove_trailing_commas(text: str) -> str:
    return re.sub(r",\s*([}\]])", r"\1", text)


def parse_json_loose(text: str) -> Any:
    blob = extract_first_json_blob(text)
    blob = remove_trailing_commas(blob)
    return json.loads(blob)


def normalize_claim(claim: Dict[str, Any], ticket_text: str = "") -> Dict[str, Any]:
    out = dict(REQUIRED_CLAIM_DEFAULTS)
    if isinstance(claim, dict):
        out.update(claim)

    out["source"] = str(out.get("source") or "customer")
    out["claim_type"] = str(out.get("claim_type") or "report")
    out["subject"] = str(out.get("subject") or "ticket")
    out["predicate"] = str(out.get("predicate") or "states")
    out["object"] = str(out.get("object") or ticket_text)

    try:
        out["confidence"] = float(out.get("confidence", 0.5))
    except Exception:
        out["confidence"] = 0.5
    out["confidence"] = max(0.0, min(1.0, out["confidence"]))

    if not isinstance(out.get("evidence"), list):
        out["evidence"] = []

    return out


def normalize_ticket_output(data: Dict[str, Any], ticket_id: str, ticket_text: str = "") -> Dict[str, Any]:
    # Accept either direct extraction object or wrapped under ticket_id.
    if ticket_id in data and isinstance(data[ticket_id], dict):
        data = data[ticket_id]

    claims = data.get("claims", [])
    if isinstance(claims, dict):
        claims = [claims]
    if not isinstance(claims, list):
        claims = []

    normalized_claims = [normalize_claim(c if isinstance(c, dict) else {}, ticket_text) for c in claims]

    # Do not invent claims unless the model gave no parseable claims.
    notes = data.get("notes", [])
    if not isinstance(notes, list):
        notes = [str(notes)]

    notes.append("c8_json_repair_applied")

    mode = data.get("suggested_router_mode", None)
    if mode is not None:
        try:
            mode = int(mode)
            if mode < 0 or mode > 4:
                mode = None
                notes.append("suggested_router_mode_out_of_range_set_null")
        except Exception:
            mode = None
            notes.append("suggested_router_mode_invalid_set_null")

    return {
        "claims": normalized_claims,
        "suggested_router_mode": mode,
        "notes": notes,
    }


def repair_file(raw_path: Path, ticket_path: Path | None, ticket_id: str | None) -> Dict[str, Any]:
    raw_text = raw_path.read_text(encoding="utf-8")
    parsed = parse_json_loose(raw_text)

    if ticket_path:
        ticket = json.loads(ticket_path.read_text(encoding="utf-8"))
        tid = ticket["ticket_id"]
        ticket_text = ticket.get("customer_text", "")
    else:
        tid = ticket_id
        ticket_text = ""

    if not tid:
        raise ValueError("ticket_id required when no ticket file is supplied.")

    return {tid: normalize_ticket_output(parsed, tid, ticket_text)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", required=True, help="Raw model output text/JSON")
    parser.add_argument("--ticket", required=False, help="Ticket JSON path")
    parser.add_argument("--ticket_id", required=False, help="Ticket ID if no ticket file")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    repaired = repair_file(Path(args.raw), Path(args.ticket) if args.ticket else None, args.ticket_id)
    Path(args.out).write_text(json.dumps(repaired, indent=2), encoding="utf-8")

    print(json.dumps({
        "ok": True,
        "out": args.out,
        "ticket_ids": list(repaired.keys()),
    }, indent=2))


if __name__ == "__main__":
    main()
