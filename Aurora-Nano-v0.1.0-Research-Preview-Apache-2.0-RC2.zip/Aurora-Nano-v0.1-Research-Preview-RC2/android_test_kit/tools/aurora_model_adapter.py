#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — B5 Real Model Adapter Scaffold

This file defines adapter interfaces for replacing simulated baselines with
actual 3B/7B extractor models.

Supported future adapter types:
- local_cli_model: calls a local model executable/script
- http_api_model: calls a local/remote model API
- python_extractor: imports a Python extractor module
- oracle_json: reads precomputed extraction outputs for repeatable testing

No external dependencies are required for the scaffold.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ExtractedClaim:
    source: str
    claim_type: str
    subject: str
    predicate: str
    object: str
    confidence: float
    evidence: List[Dict[str, Any]]


@dataclass
class ExtractorOutput:
    claims: List[ExtractedClaim]
    suggested_router_mode: Optional[int] = None
    notes: List[str] = None


class ModelExtractorAdapter:
    name = "base_model_extractor"

    def extract(self, ticket: Dict[str, Any]) -> ExtractorOutput:
        raise NotImplementedError


class OracleJsonExtractor(ModelExtractorAdapter):
    """
    Reads deterministic extraction outputs from a JSON file.

    Use this before connecting a real model to test the comparison pipeline.
    Expected file format:
    {
      "TICKET-ID": {
        "claims": [...],
        "suggested_router_mode": 2,
        "notes": [...]
      }
    }
    """

    name = "oracle_json_extractor"

    def __init__(self, oracle_path: Path):
        self.oracle_path = oracle_path
        self.oracle = json.loads(oracle_path.read_text(encoding="utf-8"))

    def extract(self, ticket: Dict[str, Any]) -> ExtractorOutput:
        ticket_id = ticket["ticket_id"]
        item = self.oracle.get(ticket_id)

        if item is None:
            # Safe fallback: customer report only.
            item = {
                "claims": [
                    {
                        "source": "customer",
                        "claim_type": "report",
                        "subject": "ticket",
                        "predicate": "states",
                        "object": ticket.get("customer_text", ""),
                        "confidence": 0.65,
                        "evidence": [{"type": "customer_text", "value": ticket.get("customer_text", "")}]
                    }
                ],
                "suggested_router_mode": None,
                "notes": ["fallback_customer_report_only"]
            }

        claims = [ExtractedClaim(**c) for c in item.get("claims", [])]
        return ExtractorOutput(
            claims=claims,
            suggested_router_mode=item.get("suggested_router_mode"),
            notes=item.get("notes", []),
        )


class LocalCliModelExtractor(ModelExtractorAdapter):
    """
    Calls a local model command.

    Contract:
    command receives ticket JSON on stdin and returns JSON:
    {
      "claims": [...],
      "suggested_router_mode": 2,
      "notes": [...]
    }
    """

    name = "local_cli_model_extractor"

    def __init__(self, command: List[str], timeout: int = 30):
        self.command = command
        self.timeout = timeout

    def extract(self, ticket: Dict[str, Any]) -> ExtractorOutput:
        proc = subprocess.run(
            self.command,
            input=json.dumps(ticket),
            capture_output=True,
            text=True,
            timeout=self.timeout,
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr)

        data = json.loads(proc.stdout)
        claims = [ExtractedClaim(**c) for c in data.get("claims", [])]
        return ExtractorOutput(
            claims=claims,
            suggested_router_mode=data.get("suggested_router_mode"),
            notes=data.get("notes", []),
        )


def build_prompt(ticket: Dict[str, Any]) -> str:
    """
    Prompt template for real LLM extractor benchmarking.
    Keep this stable so model comparisons are fair.
    """
    return f"""You are the extraction layer for Aurora Nano.

Return ONLY valid JSON with this schema:
{{
  "claims": [
    {{
      "source": "customer|agent|system|policy|external",
      "claim_type": "fact|belief|report|inference|policy|observation",
      "subject": "string",
      "predicate": "string",
      "object": "string",
      "confidence": 0.0,
      "evidence": []
    }}
  ],
  "suggested_router_mode": 0,
  "notes": []
}}

Ticket:
{json.dumps(ticket, indent=2)}
"""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ticket", required=True, help="Ticket JSON path")
    parser.add_argument("--oracle", required=False, help="Oracle extraction JSON path")
    parser.add_argument("--print_prompt", action="store_true", help="Print model extraction prompt")
    args = parser.parse_args()

    ticket = json.loads(Path(args.ticket).read_text(encoding="utf-8"))

    if args.print_prompt:
        print(build_prompt(ticket))
        return

    if args.oracle:
        adapter = OracleJsonExtractor(Path(args.oracle))
    else:
        # Default fallback adapter.
        adapter = OracleJsonExtractor(Path(__file__).with_name("aurora_b5_empty_oracle.json"))

    start = time.time()
    output = adapter.extract(ticket)
    runtime_ms = int((time.time() - start) * 1000)

    print(json.dumps({
        "adapter": adapter.name,
        "runtime_ms": runtime_ms,
        **asdict(output),
    }, indent=2))


if __name__ == "__main__":
    main()
