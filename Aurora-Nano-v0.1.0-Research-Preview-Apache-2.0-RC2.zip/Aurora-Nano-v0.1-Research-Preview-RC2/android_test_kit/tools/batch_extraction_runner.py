#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1 — B8 Batch Extraction Runner

Purpose:
Run all benchmark tickets through a selected extractor command and save
a single oracle-style JSON file:

{
  "TICKET-ID": {
    "claims": [...],
    "suggested_router_mode": null,
    "notes": [...]
  }
}

Extractor command contract:
- Receives a ticket path as the final argument OR via {ticket} placeholder.
- Prints strict JSON to stdout:
{
  "claims": [...],
  "suggested_router_mode": 2,
  "notes": [...]
}

Examples:
  python aurora_b8_batch_extraction_runner.py \
    --suite aurora_phase_b1_250_cases.json \
    --suite_dir aurora_b1_250_synthetic_suite \
    --command "python api_extractor_template.py {ticket}" \
    --out model_extractions.json

Dry run:
  python aurora_b8_batch_extraction_runner.py ... --dry_run
"""

from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List


REQUIRED_CLAIM_KEYS = {
    "source", "claim_type", "subject", "predicate", "object", "confidence", "evidence"
}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_output(raw: Dict[str, Any], ticket_id: str) -> Dict[str, Any]:
    claims = raw.get("claims", [])
    if not isinstance(claims, list):
        raise ValueError("Extractor output field `claims` must be a list.")

    normalized_claims = []
    for idx, claim in enumerate(claims):
        if not isinstance(claim, dict):
            raise ValueError(f"Claim {idx} is not an object.")
        missing = REQUIRED_CLAIM_KEYS - set(claim.keys())
        if missing:
            raise ValueError(f"Claim {idx} missing keys: {sorted(missing)}")

        normalized_claims.append({
            "source": str(claim["source"]),
            "claim_type": str(claim["claim_type"]),
            "subject": str(claim["subject"]),
            "predicate": str(claim["predicate"]),
            "object": str(claim["object"]),
            "confidence": float(claim["confidence"]),
            "evidence": claim["evidence"] if isinstance(claim["evidence"], list) else [],
        })

    mode = raw.get("suggested_router_mode")
    if mode is not None:
        mode = int(mode)

    notes = raw.get("notes", [])
    if not isinstance(notes, list):
        notes = [str(notes)]

    return {
        "claims": normalized_claims,
        "suggested_router_mode": mode,
        "notes": [str(n) for n in notes],
    }


def build_command(command_template: str, ticket_path: Path) -> List[str]:
    if "{ticket}" in command_template:
        command = command_template.replace("{ticket}", str(ticket_path))
        return shlex.split(command)

    return shlex.split(command_template) + [str(ticket_path)]


def fallback_extraction(ticket: Dict[str, Any]) -> Dict[str, Any]:
    """Useful for dry-run validation only; not a real model."""
    text = ticket.get("customer_text", "")
    return {
        "claims": [
            {
                "source": "customer",
                "claim_type": "report",
                "subject": "ticket",
                "predicate": "states",
                "object": text,
                "confidence": 0.65,
                "evidence": [{"type": "customer_text", "value": text}],
            }
        ],
        "suggested_router_mode": None,
        "notes": ["dry_run_fallback_extraction"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite", required=True)
    parser.add_argument("--suite_dir", required=True)
    parser.add_argument("--command", required=False, help="Extractor command template. Use {ticket} placeholder optionally.")
    parser.add_argument("--out", required=True)
    parser.add_argument("--log", required=False)
    parser.add_argument("--limit", type=int, required=False)
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--dry_run", action="store_true")
    args = parser.parse_args()

    suite_path = Path(args.suite)
    suite_dir = Path(args.suite_dir)
    cases = load_json(suite_path)
    if args.limit:
        cases = cases[: args.limit]

    oracle: Dict[str, Any] = {}
    log_rows: List[Dict[str, Any]] = []

    for idx, case in enumerate(cases, start=1):
        ticket_path = suite_dir / case["ticket_file"]
        ticket = load_json(ticket_path)
        ticket_id = ticket["ticket_id"]

        start = time.time()

        try:
            if args.dry_run:
                raw = fallback_extraction(ticket)
                stdout = json.dumps(raw)
                stderr = ""
                returncode = 0
            else:
                if not args.command:
                    raise ValueError("--command is required unless --dry_run is used.")

                cmd = build_command(args.command, ticket_path)
                proc = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=args.timeout,
                )
                stdout = proc.stdout
                stderr = proc.stderr
                returncode = proc.returncode

                if returncode != 0:
                    raise RuntimeError(stderr or f"Extractor returned {returncode}")

                raw = json.loads(stdout)

            normalized = normalize_output(raw, ticket_id)
            oracle[ticket_id] = normalized
            ok = True
            error = None

        except Exception as e:
            ok = False
            error = repr(e)
            stdout = locals().get("stdout", "")
            stderr = locals().get("stderr", "")
            returncode = locals().get("returncode", None)

        runtime_ms = int((time.time() - start) * 1000)
        log_rows.append({
            "index": idx,
            "case_id": case.get("case_id"),
            "ticket_id": ticket_id,
            "ok": ok,
            "runtime_ms": runtime_ms,
            "error": error,
            "returncode": returncode,
            "stdout_preview": stdout[:500] if isinstance(stdout, str) else "",
            "stderr_preview": stderr[:500] if isinstance(stderr, str) else "",
        })

    out_path = Path(args.out)
    out_path.write_text(json.dumps(oracle, indent=2), encoding="utf-8")

    log_path = Path(args.log) if args.log else out_path.with_suffix(".log.json")
    summary = {
        "suite": str(suite_path),
        "suite_dir": str(suite_dir),
        "total_requested": len(cases),
        "total_ok": sum(1 for r in log_rows if r["ok"]),
        "total_failed": sum(1 for r in log_rows if not r["ok"]),
        "oracle_output": str(out_path),
        "rows": log_rows,
    }
    log_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(json.dumps({
        "total_requested": summary["total_requested"],
        "total_ok": summary["total_ok"],
        "total_failed": summary["total_failed"],
        "oracle_output": str(out_path),
        "log": str(log_path),
    }, indent=2))


if __name__ == "__main__":
    main()
