#!/usr/bin/env python3
"""
Aurora Nano v2.2-RC1
Executable Runtime Skeleton — Phase A2

Architecture:
Input Ticket
→ Router
→ Extractor
→ Runtime Modules
→ Confidence Engine
→ Audit Log
→ Final Decision

This file is intentionally lightweight:
- No external dependencies
- Runtime-first design
- ≤7B neural core compatible
- Deterministic module interface
"""

from __future__ import annotations

import argparse
import json
import time
import uuid
import re
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from typing import Any, Dict, List, Optional


# ============================================================
# Router Modes
# ============================================================

class RouterMode(IntEnum):
    DIRECT = 0
    EXTRACTION_CONTRADICTION = 1
    POLICY_CONFIDENCE = 2
    FULL_DECISION_KERNEL = 3
    REFLECTIVE_REVIEW = 4


# ============================================================
# Schemas
# ============================================================

@dataclass
class Ticket:
    ticket_id: str
    timestamp: str
    source: str
    customer_text: str
    system_records: List[Dict[str, Any]] = field(default_factory=list)
    policy_context: List[Dict[str, Any]] = field(default_factory=list)
    available_resources: Dict[str, Any] = field(default_factory=dict)
    requested_action: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Claim:
    claim_id: str
    source: str
    claim_type: str
    subject: str
    predicate: str
    object: str
    confidence: float = 0.5
    evidence: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ModuleResult:
    module: str
    status: str
    findings: List[Dict[str, Any]] = field(default_factory=list)
    confidence_delta: float = 0.0
    recommended_action: Optional[str] = None
    audit_notes: List[str] = field(default_factory=list)


@dataclass
class ConfidenceObject:
    overall_confidence: float
    evidence_quality: float
    policy_clarity: float
    stakeholder_alignment: float
    forecast_stability: float
    counterexample_strength: float
    missing_information_penalty: float
    escalation_recommended: bool


@dataclass
class AuditLog:
    run_id: str
    ticket_id: str
    router_mode: int
    modules_executed: List[str]
    claims_extracted: List[Dict[str, Any]]
    findings: List[Dict[str, Any]]
    decision: str
    confidence: Dict[str, Any]
    escalation: Dict[str, Any]
    runtime_ms: int


# ============================================================
# Utility
# ============================================================

def clamp(x: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, x))


def load_ticket(path: str) -> Ticket:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    required = ["ticket_id", "timestamp", "source", "customer_text"]
    missing = [k for k in required if k not in data]
    if missing:
        raise ValueError(f"Ticket missing required fields: {missing}")

    return Ticket(**data)


# ============================================================
# Router
# ============================================================

class Router:
    """Selects runtime depth based on risk and complexity signals."""

    def route(self, ticket: Ticket) -> RouterMode:
        text = ticket.customer_text.lower()
        policies = len(ticket.policy_context)
        resources = bool(ticket.available_resources)

        high_risk_terms = [
            "fraud", "legal", "safety", "security", "compliance",
            "lawsuit", "medical", "refund denied"
        ]

        severe_incident_terms = [
            "breach", "security breach", "data breach"
        ]

        urgency_terms = [
            "urgent", "overdue"
        ]

        ambiguity_terms = [
            "maybe", "possibly", "likely", "uncertain", "not sure",
            "best option", "choose", "priority"
        ]

        # Severe incidents always deserve reflective review.
        if any(term in text for term in severe_incident_terms):
            return RouterMode.REFLECTIVE_REVIEW

        # High-risk domains without policy context need reflective review.
        # With policy context, keep the route more targeted unless an approval action raises execution risk.
        if any(term in text for term in high_risk_terms) and policies == 0:
            return RouterMode.REFLECTIVE_REVIEW

        if any(term in text for term in high_risk_terms) and policies > 0 and (
            "approve" in ticket.requested_action.lower() or "issue" in text
        ):
            return RouterMode.REFLECTIVE_REVIEW

        # Urgent/overdue operational risk should get reflective failure scan when no policy context exists.
        if any(term in text for term in urgency_terms) and policies == 0:
            return RouterMode.REFLECTIVE_REVIEW

        if policies > 0 and resources:
            return RouterMode.FULL_DECISION_KERNEL

        if policies > 0:
            return RouterMode.POLICY_CONFIDENCE

        if any(term in text for term in ambiguity_terms):
            return RouterMode.POLICY_CONFIDENCE

        lexical_route_markers = [
            ("approved", "denied"),
            ("eligible", "ineligible"),
            ("open", "closed"),
            ("exists", "does not exist"),
            ("arrived", "did not arrive"),
            ("paid", "unpaid"),
            ("available", "unavailable"),
            ("valid", "invalid"),
            ("active", "inactive"),
        ]

        if not policies and any(a in text and b in text for a, b in lexical_route_markers):
            return RouterMode.EXTRACTION_CONTRADICTION

        if len(text.split()) < 18 and not policies:
            return RouterMode.EXTRACTION_CONTRADICTION

        return RouterMode.POLICY_CONFIDENCE


# ============================================================
# Extractor
# ============================================================

class ClaimExtractor:
    """
    Placeholder extractor.

    In production:
    - 3B/7B neural core extracts structured claims
    - runtime validates schema
    """

    def extract(self, ticket: Ticket) -> List[Claim]:
        text = ticket.customer_text.strip()

        claims = [
            Claim(
                claim_id=f"claim_{uuid.uuid4().hex[:8]}",
                source="customer",
                claim_type="report",
                subject="ticket",
                predicate="states",
                object=text,
                confidence=0.65,
                evidence=[{"type": "customer_text", "value": text}],
            )
        ]

        for idx, record in enumerate(ticket.system_records):
            claims.append(
                Claim(
                    claim_id=f"claim_{uuid.uuid4().hex[:8]}",
                    source="system",
                    claim_type="fact",
                    subject=record.get("subject", f"system_record_{idx}"),
                    predicate=record.get("predicate", "records"),
                    object=str(record.get("object", record)),
                    confidence=0.9,
                    evidence=[{"type": "system_record", "value": record}],
                )
            )

        return claims


# ============================================================
# Runtime Module Base
# ============================================================

class RuntimeModule:
    name = "base"

    def run(
        self,
        ticket: Ticket,
        claims: List[Claim],
        state: Dict[str, Any],
        config: Dict[str, Any],
    ) -> ModuleResult:
        raise NotImplementedError


# ============================================================
# Runtime Module Stubs
# ============================================================

class LexicalContradictionModule(RuntimeModule):
    name = "lexical_contradiction"

    CONTRADICTION_PAIRS = [
        ("approved", "denied"),
        ("approve", "deny"),
        ("eligible", "ineligible"),
        ("valid", "invalid"),
        ("open", "closed"),
        ("active", "inactive"),
        ("exists", "does not exist"),
        ("arrived", "did not arrive"),
        ("paid", "unpaid"),
        ("available", "unavailable"),
        ("compliant", "noncompliant"),
    ]

    NEGATION_PATTERNS = [
        r"\bnot\s+approved\b",
        r"\bnot\s+eligible\b",
        r"\bnot\s+valid\b",
        r"\bdid\s+not\s+arrive\b",
        r"\bdoes\s+not\s+exist\b",
        r"\bno\s+record\b",
    ]

    def run(self, ticket, claims, state, config):
        findings = []
        text = ticket.customer_text.lower()

        for a, b in self.CONTRADICTION_PAIRS:
            if a in text and b in text:
                findings.append({
                    "type": "lexical_contradiction",
                    "pair": [a, b],
                    "severity": "medium",
                    "note": f"Detected both '{a}' and '{b}'."
                })

        for pattern in self.NEGATION_PATTERNS:
            if re.search(pattern, text):
                findings.append({
                    "type": "negated_claim",
                    "pattern": pattern,
                    "severity": "info"
                })

        return ModuleResult(
            module=self.name,
            status="warn" if any(f.get("type") == "lexical_contradiction" for f in findings) else "pass",
            findings=findings,
            confidence_delta=-0.08 if any(f.get("type") == "lexical_contradiction" for f in findings) else 0.02,
            audit_notes=["Checked lexical contradiction and negation patterns."]
        )


class TemporalLogicModule(RuntimeModule):
    name = "temporal_logic"

    BEFORE_TERMS = ["before", "prior to", "earlier than", "preceding"]
    AFTER_TERMS = ["after", "later than", "following", "subsequent to"]
    ON_TIME_TERMS = [
        "on time",
        "within deadline",
        "before deadline",
        "deadline met",
        "submitted on time",
        "filed on time",
        "arrived on time",
    ]
    LATE_TERMS = [
        "late",
        "after deadline",
        "deadline missed",
        "deadline was missed",
        "missed deadline",
        "missed the deadline",
        "overdue",
        "submitted late",
        "filed late",
        "arrived late",
    ]

    def run(self, ticket, claims, state, config):
        text = ticket.customer_text.lower()
        findings = []

        has_before = any(t in text for t in self.BEFORE_TERMS)
        has_after = any(t in text for t in self.AFTER_TERMS)
        has_on_time = any(t in text for t in self.ON_TIME_TERMS)
        has_late = any(t in text for t in self.LATE_TERMS)

        if has_before and has_after:
            findings.append({
                "type": "temporal_conflict_possible",
                "severity": "medium",
                "note": "Detected before/after relationship terms."
            })

        if has_on_time and has_late:
            findings.append({
                "type": "deadline_conflict",
                "severity": "medium",
                "note": "Detected on-time/late or deadline-met/deadline-missed conflict."
            })

        return ModuleResult(
            module=self.name,
            status="warn" if findings else "pass",
            findings=findings,
            confidence_delta=-0.06 if findings else 0.01,
            audit_notes=["Temporal relation and deadline scan completed."]
        )


class PerspectiveSourceModule(RuntimeModule):
    name = "perspective_source"

    STATUS_VALUES = {
        "approved": ["approved", "approval granted"],
        "denied": ["denied", "rejected", "not approved"],
        "paid": ["paid", "payment complete"],
        "unpaid": ["unpaid", "payment missing"],
        "delivered": ["delivered", "arrived"],
        "not_delivered": ["not delivered", "did not arrive", "missing"],
    }

    CONFLICTS = [
        ("approved", "denied"),
        ("paid", "unpaid"),
        ("delivered", "not_delivered"),
    ]

    def _detect_statuses(self, value: str):
        value = str(value).lower()
        found = set()

        # Negative/compound statuses first to avoid substring false positives.
        if any(term in value for term in ["not approved", "denied", "rejected"]):
            found.add("denied")
        elif any(term in value for term in ["approved", "approval granted"]):
            found.add("approved")

        if any(term in value for term in ["unpaid", "payment missing"]):
            found.add("unpaid")
        elif any(term in value for term in ["paid", "payment complete"]):
            found.add("paid")

        if any(term in value for term in ["not delivered", "did not arrive", "missing"]):
            found.add("not_delivered")
        elif any(term in value for term in ["delivered", "arrived"]):
            found.add("delivered")

        return found

    def run(self, ticket, claims, state, config):
        findings = []
        by_source = {}

        for claim in claims:
            # Avoid double-counting the entire customer_text claim as a structured status.
            # Customer text is handled explicitly below; system records remain structured facts.
            if claim.source == "customer" and claim.claim_type == "report":
                continue
            statuses = self._detect_statuses(claim.object)
            if statuses:
                by_source.setdefault(claim.source, set()).update(statuses)

        # Include customer text explicitly as customer perspective.
        customer_statuses = self._detect_statuses(ticket.customer_text)
        if customer_statuses:
            by_source.setdefault("customer", set()).update(customer_statuses)

        for record in ticket.system_records:
            record_statuses = self._detect_statuses(record)
            if record_statuses:
                by_source.setdefault("system", set()).update(record_statuses)

        for left, right in self.CONFLICTS:
            sources_left = [s for s, vals in by_source.items() if left in vals]
            sources_right = [s for s, vals in by_source.items() if right in vals]

            if sources_left and sources_right:
                same_source = bool(set(sources_left) & set(sources_right))
                findings.append({
                    "type": "same_source_contradiction" if same_source else "source_conflict",
                    "severity": "high" if same_source else "medium",
                    "left": left,
                    "right": right,
                    "sources_left": sources_left,
                    "sources_right": sources_right,
                    "note": "Same source contradiction." if same_source else "Different sources disagree; treat as dispute, not direct contradiction."
                })

        state["source_status_map"] = {k: sorted(v) for k, v in by_source.items()}

        return ModuleResult(
            module=self.name,
            status="warn" if findings else "pass",
            findings=findings,
            confidence_delta=-0.02 if any(f["severity"] == "high" for f in findings) else (-0.04 if findings else 0.03),
            audit_notes=["Perspective/source conflict scan completed."]
        )


class PolicyResolutionModule(RuntimeModule):
    name = "policy_resolution"

    HIGH_AUTHORITY_TERMS = ["safety", "legal", "compliance", "security", "regulatory"]
    EXCEPTION_TERMS = ["except", "exception", "unless", "requires", "require", "required", "must", "prohibited", "prohibit", "waiver"]

    def run(self, ticket, claims, state, config):
        findings = []
        policy_text = " ".join(str(p) for p in ticket.policy_context).lower()

        if ticket.policy_context:
            findings.append({
                "type": "policy_context_present",
                "count": len(ticket.policy_context),
                "severity": "info"
            })

            if any(term in policy_text for term in self.HIGH_AUTHORITY_TERMS):
                findings.append({
                    "type": "high_authority_policy_detected",
                    "severity": "medium",
                    "note": "Safety/legal/compliance/security language detected."
                })

            if any(term in policy_text for term in self.EXCEPTION_TERMS):
                findings.append({
                    "type": "policy_exception_or_requirement_detected",
                    "severity": "medium",
                    "note": "Exception/requirement/prohibition language detected."
                })

            action = "apply_policy_context"
            delta = 0.08
        else:
            action = None
            delta = -0.05
            findings.append({
                "type": "missing_policy_context",
                "severity": "medium",
                "note": "No policy context supplied."
            })

        return ModuleResult(
            module=self.name,
            status="pass" if ticket.policy_context else "warn",
            findings=findings,
            confidence_delta=delta,
            recommended_action=action,
            audit_notes=["Policy confidence/resolution scan executed."]
        )


class UtilityDecisionModule(RuntimeModule):
    name = "utility_decision"

    def run(self, ticket, claims, state, config):
        findings = []

        if ticket.available_resources:
            findings.append({
                "type": "resource_context_present",
                "severity": "info",
                "resources": ticket.available_resources
            })

            queue_depth = ticket.available_resources.get("queue_depth")
            agents = ticket.available_resources.get("review_agents_available")
            if isinstance(queue_depth, int) and isinstance(agents, int) and agents > 0:
                load = queue_depth / agents
                findings.append({
                    "type": "capacity_load",
                    "severity": "medium" if load >= 10 else "info",
                    "load": round(load, 2)
                })

        return ModuleResult(
            module=self.name,
            status="pass",
            findings=findings,
            confidence_delta=0.02,
            recommended_action="rank_options_if_available",
            audit_notes=["Utility/capacity decision scan executed."]
        )


class SelfCritiqueModule(RuntimeModule):
    name = "self_critique"

    HIGH_RISK_TERMS = ["legal", "compliance", "refund", "safety", "security", "fraud", "breach"]

    def run(self, ticket, claims, state, config):
        findings = []
        text = ticket.customer_text.lower()

        if not ticket.policy_context and any(term in text for term in self.HIGH_RISK_TERMS):
            findings.append({
                "type": "missing_policy_context",
                "severity": "high",
                "note": "High-risk domain term found without policy context."
            })

        if "source_conflict" in str(state.get("source_status_map", {})).lower():
            findings.append({
                "type": "review_source_conflict",
                "severity": "medium"
            })

        return ModuleResult(
            module=self.name,
            status="warn" if findings else "pass",
            findings=findings,
            confidence_delta=-0.12 if findings else 0.03,
            audit_notes=["Self-critique pass completed."]
        )


class CounterexampleModule(RuntimeModule):
    name = "counterexample_discovery"

    def run(self, ticket, claims, state, config):
        findings = []

        action = ticket.requested_action.lower()
        if any(term in action for term in ["approve", "pay", "close", "deny"]):
            findings.append({
                "type": "counterexample",
                "severity": "info",
                "question": "Is there a policy exception, fraud risk, source conflict, or missing evidence?"
            })

        return ModuleResult(
            module=self.name,
            status="pass",
            findings=findings,
            confidence_delta=-0.02 if findings else 0.01,
            audit_notes=["Counterexample discovery stub completed."]
        )


class FailurePredictionModule(RuntimeModule):
    name = "failure_prediction"

    def run(self, ticket, claims, state, config):
        findings = []

        text = ticket.customer_text.lower()
        if any(term in text for term in ["urgent", "overdue", "breach", "fraud", "security"]):
            findings.append({
                "type": "failure_risk",
                "severity": "medium",
                "note": "Risk-bearing term detected."
            })

        if not ticket.policy_context and any(term in text for term in ["refund", "legal", "compliance", "fraud"]):
            findings.append({
                "type": "execution_failure_risk",
                "severity": "high",
                "note": "Decision may fail because policy context is missing."
            })

        return ModuleResult(
            module=self.name,
            status="warn" if findings else "pass",
            findings=findings,
            confidence_delta=-0.08 if any(f.get("severity") == "high" for f in findings) else (-0.05 if findings else 0.02),
            audit_notes=["Failure prediction scan completed."]
        )


# ============================================================
# Confidence Engine
# ============================================================

class ConfidenceEngine:
    def compute(
        self,
        ticket: Ticket,
        claims: List[Claim],
        module_results: List[ModuleResult],
    ) -> ConfidenceObject:
        base = 0.72

        evidence_quality = 0.65
        if ticket.system_records:
            evidence_quality += 0.15
        if len(claims) > 1:
            evidence_quality += 0.05
        evidence_quality = clamp(evidence_quality)

        policy_clarity = 0.35 if not ticket.policy_context else 0.8
        stakeholder_alignment = 0.65
        forecast_stability = 0.65

        counterexample_strength = 0.0
        missing_information_penalty = 0.0

        for result in module_results:
            base += result.confidence_delta
            for finding in result.findings:
                severity = finding.get("severity")
                ftype = finding.get("type")
                if severity == "high":
                    if ftype in ["missing_policy_context", "execution_failure_risk"]:
                        missing_information_penalty += 0.15
                    else:
                        missing_information_penalty += 0.05
                elif severity == "medium":
                    missing_information_penalty += 0.04

                if finding.get("type") == "counterexample":
                    counterexample_strength += 0.08

        overall = clamp(
            base
            + 0.10 * evidence_quality
            + 0.08 * policy_clarity
            - counterexample_strength
            - missing_information_penalty
        )

        escalation = overall < 0.60 or missing_information_penalty >= 0.15

        return ConfidenceObject(
            overall_confidence=round(overall, 3),
            evidence_quality=round(evidence_quality, 3),
            policy_clarity=round(policy_clarity, 3),
            stakeholder_alignment=round(stakeholder_alignment, 3),
            forecast_stability=round(forecast_stability, 3),
            counterexample_strength=round(clamp(counterexample_strength), 3),
            missing_information_penalty=round(clamp(missing_information_penalty), 3),
            escalation_recommended=bool(escalation),
        )


# ============================================================
# Runtime Orchestrator
# ============================================================

class AuroraNanoRuntime:
    def __init__(self):
        self.router = Router()
        self.extractor = ClaimExtractor()
        self.confidence_engine = ConfidenceEngine()

        self.modules_by_mode = {
            RouterMode.DIRECT: [],
            RouterMode.EXTRACTION_CONTRADICTION: [
                LexicalContradictionModule(),
                TemporalLogicModule(),
                PerspectiveSourceModule(),
            ],
            RouterMode.POLICY_CONFIDENCE: [
                LexicalContradictionModule(),
                TemporalLogicModule(),
                PerspectiveSourceModule(),
                PolicyResolutionModule(),
            ],
            RouterMode.FULL_DECISION_KERNEL: [
                LexicalContradictionModule(),
                TemporalLogicModule(),
                PerspectiveSourceModule(),
                PolicyResolutionModule(),
                UtilityDecisionModule(),
                FailurePredictionModule(),
            ],
            RouterMode.REFLECTIVE_REVIEW: [
                LexicalContradictionModule(),
                TemporalLogicModule(),
                PerspectiveSourceModule(),
                PolicyResolutionModule(),
                UtilityDecisionModule(),
                SelfCritiqueModule(),
                CounterexampleModule(),
                FailurePredictionModule(),
            ],
        }

    def run(self, ticket: Ticket, config: Optional[Dict[str, Any]] = None, external_claims: Optional[List[Dict[str, Any]]] = None, forced_router_mode: Optional[int] = None) -> Dict[str, Any]:
        start = time.time()
        config = config or {}
        state: Dict[str, Any] = {}

        run_id = f"run_{uuid.uuid4().hex[:12]}"
        mode = RouterMode(forced_router_mode) if forced_router_mode is not None else self.router.route(ticket)

        if external_claims is not None:
            claims = [
                Claim(
                    claim_id=c.get("claim_id", f"external_{uuid.uuid4().hex[:8]}"),
                    source=c.get("source", "external"),
                    claim_type=c.get("claim_type", "report"),
                    subject=c.get("subject", "ticket"),
                    predicate=c.get("predicate", "states"),
                    object=str(c.get("object", "")),
                    confidence=float(c.get("confidence", 0.5)),
                    evidence=c.get("evidence", []),
                )
                for c in external_claims
            ]
        else:
            claims = self.extractor.extract(ticket)

        module_results: List[ModuleResult] = []
        for module in self.modules_by_mode[mode]:
            module_results.append(module.run(ticket, claims, state, config))

        confidence = self.confidence_engine.compute(ticket, claims, module_results)
        decision = self._make_decision(ticket, module_results, confidence)

        findings = []
        for result in module_results:
            findings.extend(result.findings)

        runtime_ms = int((time.time() - start) * 1000)

        audit = AuditLog(
            run_id=run_id,
            ticket_id=ticket.ticket_id,
            router_mode=int(mode),
            modules_executed=[r.module for r in module_results],
            claims_extracted=[asdict(c) for c in claims],
            findings=findings,
            decision=decision,
            confidence=asdict(confidence),
            escalation={
                "recommended": confidence.escalation_recommended,
                "reason": "low confidence or missing information"
                if confidence.escalation_recommended else None,
            },
            runtime_ms=runtime_ms,
        )

        return {
            "run_id": run_id,
            "ticket_id": ticket.ticket_id,
            "router_mode": int(mode),
            "decision": decision,
            "confidence": asdict(confidence),
            "module_results": [asdict(r) for r in module_results],
            "audit_log": asdict(audit),
        }

    def _make_decision(
        self,
        ticket: Ticket,
        module_results: List[ModuleResult],
        confidence: ConfidenceObject,
    ) -> str:
        if confidence.escalation_recommended:
            return "escalate_for_review"

        for result in module_results:
            if result.status == "warn" and any(
                f.get("severity") == "high" for f in result.findings
            ):
                return "hold_pending_missing_context"

        recommended = [
            r.recommended_action for r in module_results if r.recommended_action
        ]

        if recommended:
            return recommended[-1]

        if ticket.requested_action:
            return f"proceed_with_requested_action:{ticket.requested_action}"

        return "provide_standard_response"


# ============================================================
# CLI
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(description="Aurora Nano v2.2-RC1 Runtime Skeleton")
    parser.add_argument("--ticket", required=True, help="Path to ticket JSON")
    parser.add_argument("--out", required=False, help="Optional output JSON path")
    args = parser.parse_args()

    ticket = load_ticket(args.ticket)
    runtime = AuroraNanoRuntime()
    result = runtime.run(ticket)

    output = json.dumps(result, indent=2)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(output)
    else:
        print(output)


if __name__ == "__main__":
    main()
