#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "Aurora Android Kit — full 250-ticket validation"
echo "Expected oracle: outputs/model_250_oracle.json"

python "$ROOT/tools/json_validity_analyzer.py" \
  --oracle "$ROOT/outputs/model_250_oracle.json" \
  --suite "$ROOT/tickets_250/cases_250.json" \
  --suite_dir "$ROOT/tickets_250" \
  --out "$ROOT/outputs/model_250_validity.json" \
  --summary "$ROOT/outputs/model_250_validity.md"

python "$ROOT/tools/score_250_full.py" \
  --oracle "$ROOT/outputs/model_250_oracle.json" \
  --suite "$ROOT/tickets_250/cases_250.json" \
  --suite_dir "$ROOT/tickets_250" \
  --runtime "$ROOT/runtime/aurora_runtime.py" \
  --adapter_scaffold "$ROOT/tools/aurora_model_adapter.py" \
  --validity_analyzer "$ROOT/tools/json_validity_analyzer.py" \
  --out_dir "$ROOT/outputs/c4_250_results" \
  --label "android_model_250"

echo "Done. See outputs/c4_250_results/android_model_250_c4_summary.md"
