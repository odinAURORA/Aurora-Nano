#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "Aurora Android Kit — 25-ticket validation"
echo "Expected oracle: outputs/model_25_oracle.json"

python "$ROOT/tools/json_validity_analyzer.py" \
  --oracle "$ROOT/outputs/model_25_oracle.json" \
  --suite "$ROOT/tickets_25/cases_25.json" \
  --suite_dir "$ROOT/tickets_25" \
  --out "$ROOT/outputs/model_25_validity.json" \
  --summary "$ROOT/outputs/model_25_validity.md"

python "$ROOT/tools/score_25_smoke.py" \
  --oracle "$ROOT/outputs/model_25_oracle.json" \
  --suite "$ROOT/tickets_25/cases_25.json" \
  --suite_dir "$ROOT/tickets_25" \
  --runtime "$ROOT/runtime/aurora_runtime.py" \
  --adapter_scaffold "$ROOT/tools/aurora_model_adapter.py" \
  --validity_analyzer "$ROOT/tools/json_validity_analyzer.py" \
  --out_dir "$ROOT/outputs/c3_25_results" \
  --label "android_model_25"

echo "Done. See outputs/c3_25_results/android_model_25_c3_summary.md"
