# Quick Android / Termux Setup

## 1. Install basics

```bash
pkg update
pkg install python unzip
```

## 2. Unzip kit

```bash
unzip aurora_android_real_model_test_kit.zip
cd aurora_android_real_model_test_kit
```

## 3. Run first prompt

```bash
python tools/make_prompt.py tickets_25/b1-l001_ticket.json > outputs/prompt_001.txt
```

Open `outputs/prompt_001.txt`, feed it to your local model, and save the reply to:

```text
outputs/raw_001.txt
```

## 4. Repair and score

```bash
python tools/json_repair_wrapper.py --raw outputs/raw_001.txt --ticket tickets_25/b1-l001_ticket.json --out outputs/oracle_001.json

python tools/score_one.py tickets_25/b1-l001_ticket.json outputs/oracle_001.json
```

## 5. Build 25-ticket oracle

Once single-ticket works, create `outputs/model_25_oracle.json`, then:

```bash
bash scripts/score_25_oracle.sh
```
