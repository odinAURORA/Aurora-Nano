# Aurora Nano — D1-M6B Forecasting Simulation

## Purpose
Forecast whether Aurora Nano is likely to improve real small models before spending compute on full validation.

## Important Boundary
This is a simulation, not a real benchmark. It uses current public model facts and estimated behavior from model size, instruction-following expectations, JSON reliability assumptions, and Aurora's deterministic runtime design.

## Models Considered
- Llama 3.2 3B Instruct
- Qwen3 4B Instruct
- Gemma 3 4B IT
- Phi-4-mini-instruct
- SmolLM3 3B Instruct

## Overall Forecast

| Model | Params | Model-only | Aurora+Model | Delta | P(Runtime wins) | P(Delta ≥ 10%) |
|---|---:|---:|---:|---:|---:|---:|
| Qwen3 4B Instruct | 4.0B | 0.75 | 0.929 | 0.179 | 1.0 | 1.0 |
| Gemma 3 4B IT | 4.0B | 0.729 | 0.914 | 0.186 | 1.0 | 1.0 |
| Phi-4-mini-instruct | 3.8B | 0.732 | 0.908 | 0.176 | 1.0 | 1.0 |
| Llama 3.2 3B Instruct | 3.0B | 0.679 | 0.878 | 0.199 | 1.0 | 1.0 |
| SmolLM3 3B Instruct | 3.0B | 0.656 | 0.859 | 0.203 | 1.0 | 1.0 |

## Recommended Test Order

1. **Qwen3 4B Instruct** — highest projected runtime+model score.
2. **Gemma 3 4B IT** — strong balanced second test.
3. **Phi-4-mini-instruct** — strong reasoning-dense alternative.
4. **Llama 3.2 3B Instruct** — still the best pure 3B edge proof.
5. **SmolLM3 3B Instruct** — useful low-cost stress comparison.

## Strategic Takeaway
The forecast predicts Aurora adds the most value in:
- source conflict detection
- policy/requirement handling
- escalation logic
- temporal contradiction consistency

The runtime adds less value on cases where the model already produces perfect structured reasoning, and it cannot rescue cases where the extractor fails to produce usable claims.

## Category Forecasts

## Qwen3 4B Instruct

| Category | Model-only | Aurora+Model | Delta |
|---|---:|---:|---:|
| lexical | 0.852 | 1 | 0.148 |
| temporal | 0.789 | 0.939 | 0.15 |
| source_conflict | 0.703 | 0.927 | 0.223 |
| policy | 0.72 | 0.92 | 0.2 |
| resource_escalation | 0.684 | 0.868 | 0.184 |

## Gemma 3 4B IT

| Category | Model-only | Aurora+Model | Delta |
|---|---:|---:|---:|
| lexical | 0.834 | 0.98 | 0.146 |
| temporal | 0.772 | 0.928 | 0.156 |
| source_conflict | 0.68 | 0.911 | 0.231 |
| policy | 0.697 | 0.904 | 0.207 |
| resource_escalation | 0.661 | 0.852 | 0.191 |

## Phi-4-mini-instruct

| Category | Model-only | Aurora+Model | Delta |
|---|---:|---:|---:|
| lexical | 0.845 | 0.97 | 0.125 |
| temporal | 0.789 | 0.936 | 0.147 |
| source_conflict | 0.674 | 0.899 | 0.225 |
| policy | 0.691 | 0.892 | 0.201 |
| resource_escalation | 0.659 | 0.843 | 0.184 |

## Llama 3.2 3B Instruct

| Category | Model-only | Aurora+Model | Delta |
|---|---:|---:|---:|
| lexical | 0.797 | 0.96 | 0.163 |
| temporal | 0.728 | 0.892 | 0.165 |
| source_conflict | 0.619 | 0.865 | 0.246 |
| policy | 0.648 | 0.866 | 0.218 |
| resource_escalation | 0.604 | 0.807 | 0.202 |

## SmolLM3 3B Instruct

| Category | Model-only | Aurora+Model | Delta |
|---|---:|---:|---:|
| lexical | 0.776 | 0.93 | 0.154 |
| temporal | 0.708 | 0.878 | 0.171 |
| source_conflict | 0.601 | 0.853 | 0.252 |
| policy | 0.618 | 0.844 | 0.227 |
| resource_escalation | 0.579 | 0.788 | 0.209 |


## Recommendation
Do not run only Llama first if the goal is best chance of success. Run:

```text
D1: Llama 3.2 3B — edge thesis
D2: Qwen3 4B — strongest practical candidate
D3: Gemma 3 4B — structured-output comparison
D4: Phi-4-mini — reasoning-dense comparison
```

If time is limited, run **Qwen3 4B first** for best projected score, then **Llama 3.2 3B** for the edge story.
