# Aurora Nano — D1-M6B Summary

## Status
Forecasting/simulation completed.

## Top Forecasted Runtime+Model Candidate
**Qwen3 4B Instruct**

Expected:
- Model-only: 0.75
- Aurora+Model: 0.929
- Delta: 0.179

## Best Edge-Proof Candidate
**Llama 3.2 3B Instruct**

Still best for proving Aurora Nano works with a true 3B-class model.

## Recommended Plan
1. Run Qwen3 4B first if we want highest chance of strong score.
2. Run Llama 3.2 3B first if we want the cleanest “Aurora Nano Edge” proof.
3. Do not build more framework before at least one real 25-ticket smoke run.

## Files
- `aurora_d1_m6b_forecast_report.md`
- `aurora_d1_m6b_model_forecast_simulation.json`
- `aurora_d1_m6b_decision_matrix.json`

## Boundary
This is a forecast, not a real benchmark.
