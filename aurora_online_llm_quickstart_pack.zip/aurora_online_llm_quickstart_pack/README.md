# Aurora Online LLM Quickstart Pack

Use Aurora Nano with ChatGPT, Claude, Gemini, Perplexity, Grok, or any online LLM.

## Simple Idea

Your model does the language part.

Aurora does the consistency-checking part.

```text
Ticket / Input
  ↓
Online LLM extracts claims as JSON
  ↓
Aurora validates / repairs JSON
  ↓
Aurora runtime checks contradiction, policy, source conflict, risk
  ↓
Decision + confidence + audit trail
```

## Fastest Workflow

1. Copy `prompts/aurora_claim_extraction_prompt.md`.
2. Paste one benchmark ticket into the prompt.
3. Ask your preferred online LLM to return only JSON.
4. Save the JSON as `oracle.json`.
5. Run Aurora scoring tools from the main repo.

## What To Ask The LLM

Ask the model to extract claims, not make the final decision.

The goal is:

```text
structured extraction first
runtime decision second
```

## Why This Works

Most online LLMs are already good at reading text and producing structured JSON.

Aurora adds:
- contradiction checks
- source conflict checks
- policy/risk routing
- confidence object
- audit trail

## Important

This pack does not include private API keys, model calls, or hosted services. It is a prompt-and-schema pack.
