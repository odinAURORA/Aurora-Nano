# Using Aurora With Online LLMs

## Works With

- ChatGPT
- Claude
- Gemini
- Grok
- Perplexity
- Hugging Face chat models
- API models

## Best Practice

Ask the model to do extraction only.

Bad:

```text
Decide whether to approve this refund.
```

Better:

```text
Extract structured claims from this ticket using Aurora's schema.
```

## Why

If the model makes the whole decision, Aurora cannot check its reasoning.

If the model extracts claims, Aurora can:

- detect contradictions
- compare sources
- apply policy logic
- decide escalation
- produce audit trail

## Minimal Pseudocode

```python
ticket = load_json("ticket.json")

prompt = make_aurora_prompt(ticket)

model_output = online_llm(prompt)

oracle = repair_or_validate_json(model_output)

result = aurora.run(
    ticket=ticket,
    external_claims=oracle["claims"],
    forced_router_mode=oracle.get("suggested_router_mode")
)

print(result["decision"])
print(result["confidence"])
print(result["audit_log"])
```

## Human Workflow

1. Open your online LLM.
2. Paste `aurora_claim_extraction_prompt.md`.
3. Paste a ticket JSON.
4. Copy the model JSON response.
5. Save it as an oracle JSON.
6. Run Aurora scoring.

## Important

Do not claim benchmark results unless the output has been scored with Aurora tools.
