# Online LLM Quickstart

Aurora can be tested with online LLMs.

The LLM should extract structured claims as JSON. Aurora then performs contradiction checks, policy/risk routing, confidence scoring, and audit logging.

Minimal flow:

```text
Online LLM = extraction
Aurora = consistency and decision runtime
```

Use the prompt pack:

```text
aurora_online_llm_quickstart_pack.zip
```

This works with ChatGPT, Claude, Gemini, Grok, Perplexity, and other online models.
