Extract Aurora Nano claims from the ticket below.

Return only JSON with:
{
  "claims": [
    {
      "source": "customer|agent|system|policy|external",
      "claim_type": "fact|belief|report|inference|policy|observation",
      "subject": "string",
      "predicate": "string",
      "object": "string",
      "confidence": 0.0,
      "evidence": []
    }
  ],
  "suggested_router_mode": null,
  "notes": []
}

Do not make the final decision. Extract claims only.

Ticket:
PASTE_TICKET_JSON_HERE
