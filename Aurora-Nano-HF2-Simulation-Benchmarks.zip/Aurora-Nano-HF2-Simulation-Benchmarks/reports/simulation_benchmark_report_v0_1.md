# Aurora Nano HF-2 Simulation Benchmarks

## Purpose

This pack provides simulation benchmarks and contribution templates for Aurora Nano.

The goal is to help the community understand what Aurora is expected to measure before real benchmark results are collected.

## Critical Label

These results are:

```text
SIMULATION_NOT_REAL_BENCHMARK
```

They are forecasts based on model class, expected JSON reliability, structured-output behavior, and Aurora runtime design. They should not be treated as measured performance.

## Forecast Leaderboard

| Priority | Model | Params | Model-only Forecast | Aurora+Model Forecast | Delta |
|---:|---|---:|---:|---:|---:|
| 1 | Qwen3 4B Instruct | 4B | 0.75 | 0.929 | 0.179 |
| 2 | Gemma 3 4B IT | 4B | 0.733 | 0.904 | 0.171 |
| 3 | Phi-4-mini-instruct | 3.8B | 0.748 | 0.895 | 0.147 |
| 4 | Llama 3.2 3B Instruct | 3B | 0.704 | 0.865 | 0.161 |
| 5 | SmolLM3 3B Instruct | 3B | 0.675 | 0.842 | 0.167 |

## What The Simulation Suggests

Aurora is expected to help most with:

- source conflict detection
- policy and requirement handling
- escalation decisions
- contradiction consistency
- temporal/deadline conflicts

Aurora is expected to help least where the model already extracts and reasons perfectly.

## Community Testing Request

If you can run local models, please test Aurora Nano and submit real results.

Best first targets:

1. Qwen3 4B
2. Llama 3.2 3B
3. Gemma 3 4B
4. Phi-4-mini
5. SmolLM3 3B

Use:

```text
templates/real_benchmark_submission_template.json
```

## Related Project

Source code and runtime are available in the Aurora Nano GitHub repository.
