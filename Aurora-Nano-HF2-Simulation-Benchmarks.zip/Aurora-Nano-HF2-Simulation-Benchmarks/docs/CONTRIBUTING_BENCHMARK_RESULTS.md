# Contributing Real Aurora Nano Benchmark Results

Thank you for helping test Aurora Nano.

## What We Need

Please submit real benchmark results for small models, especially:

- Qwen3 4B
- Llama 3.2 3B
- Gemma 3 4B
- Phi-4-mini
- SmolLM3 3B
- Other 3B–7B local models

## Minimum Accepted Result

A useful submission should include:

1. Model name and quantization.
2. Device / hardware details.
3. JSON validity score.
4. Aurora runtime score.
5. Model-only score if available.
6. Runtime-minus-model delta.
7. C4 or C6 report file.

## How To Run

Use the GitHub repository release package:

1. Generate model extraction outputs.
2. Validate with C2.
3. Score runtime+model with C4.
4. Score model-only with C5.
5. Compare with C6.
6. Audit latency with C9.

## Important

Simulation results in this dataset are clearly labeled:

```text
SIMULATION_NOT_REAL_BENCHMARK
```

Please label real results as:

```text
REAL_BENCHMARK
```

## Submission Format

Use:

```text
templates/real_benchmark_submission_template.json
```

You can share results by opening a GitHub issue, pull request, or discussion in the Aurora Nano repository.
