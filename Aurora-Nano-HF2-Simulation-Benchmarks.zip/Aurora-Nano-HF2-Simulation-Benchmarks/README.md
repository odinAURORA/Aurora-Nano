---
license: apache-2.0
pretty_name: Aurora Nano HF-2 Simulation Benchmarks
task_categories:
- text-classification
- question-answering
- text-generation
tags:
- evaluation
- small-language-models
- local-llm
- benchmark
- runtime
- structured-output
---

# Aurora Nano HF-2 Simulation Benchmarks

Aurora Nano is a lightweight runtime and evaluation framework for studying whether deterministic runtime systems can improve consistency, contradiction handling, escalation behavior, and structured decision quality in small language models.

## What This Dataset Contains

- Simulation benchmark forecasts for 3B–4B class models
- Category-level forecast data
- A benchmark submission template
- Instructions for community real-model testing

## Important

The included model scores are **simulations**, not measured benchmark results.

They are labeled:

```text
SIMULATION_NOT_REAL_BENCHMARK
```

Real results should be labeled:

```text
REAL_BENCHMARK
```

## Forecasted Models

- Qwen3 4B Instruct
- Llama 3.2 3B Instruct
- Gemma 3 4B IT
- Phi-4-mini-instruct
- SmolLM3 3B Instruct

## Community Testing

If you can run local models, please test Aurora Nano and submit results using:

```text
templates/real_benchmark_submission_template.json
```

Preferred benchmark targets:

1. Qwen3 4B
2. Llama 3.2 3B
3. Gemma 3 4B
4. Phi-4-mini
5. SmolLM3 3B

## Files

```text
data/simulation_leaderboard_v0_1.csv
data/simulation_leaderboard_v0_1.json
data/category_forecast_v0_1.csv
data/category_forecast_v0_1.json
reports/simulation_benchmark_report_v0_1.md
templates/real_benchmark_submission_template.json
docs/CONTRIBUTING_BENCHMARK_RESULTS.md
```

## License

Apache-2.0
